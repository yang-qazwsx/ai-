-- ============================================================
-- 新增「图书推荐」意图，配合 AiServiceImpl.recommendBooks 的结构化推荐
-- 幂等：已存在则跳过（intent_name 有唯一索引，重复执行安全）
-- 执行库：ry-cloud
-- 注意：代码侧另有 RECOMMEND_HINTS 特征词兜底，即使未执行本脚本，
--       "推荐/书单/有什么书"等问法仍会走推荐链路；执行后意图标签才准确。
-- ============================================================
INSERT INTO ai_intent (intent_name, intent_desc, keywords)
SELECT '图书推荐', '按分类/价格/库存推荐在售图书', '推荐,推荐几本,书单,有什么书,有哪些书,买什么书,看什么书,选书'
WHERE NOT EXISTS (SELECT 1 FROM ai_intent WHERE intent_name = '图书推荐');

SELECT id, intent_name, keywords FROM ai_intent WHERE intent_name = '图书推荐';
