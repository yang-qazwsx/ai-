package com.ruoyi.system.service.impl;

import com.ruoyi.common.core.exception.ServiceException;
import com.ruoyi.common.core.utils.StringUtils;
import com.ruoyi.system.domain.BizBook;
import com.ruoyi.system.domain.BizBookChunk;
import com.ruoyi.system.domain.BizBookContent;
import com.ruoyi.system.domain.BookChunkDTO;
import com.ruoyi.system.domain.BookOutlineDTO;
import com.ruoyi.system.mapper.BizBookContentMapper;
import com.ruoyi.system.mapper.BizBookMapper;
import com.ruoyi.system.service.IAiBookContentService;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * 书籍内容服务实现
 *
 * 处理链路：上传文件 → UTF-8 解码 → 按 500 字滑窗分片（重叠 50，尽量在句号处断开）
 * → 分片落库 biz_book_chunk → 写入 Redis 向量库（metadata 打 type=book 供检索区分）。
 *
 * 向量库与知识库共用 aa_rag_index，索引 schema 只把 knowledgeId / answer 建了字段，
 * 所以 type / bookId / chunkNo 只能随 hash 存取、不能做 filter —— 检索时多取再内存过滤。
 *
 * @author ruoyi
 */
@Service
public class AiBookContentServiceImpl implements IAiBookContentService
{
    private static final Logger log = LoggerFactory.getLogger(AiBookContentServiceImpl.class);

    /** 单片最大字数（可配置，见 ai.book.chunk-size） */
    @Value("${ai.book.chunk-size:500}")
    private int chunkSize;

    /** 相邻分片重叠字数，避免句子被切断后语义缺失 */
    @Value("${ai.book.chunk-overlap:50}")
    private int chunkOverlap;

    /** 向量写入批大小 */
    @Value("${ai.book.vector-batch:50}")
    private int vectorBatch;

    /** 书籍正文检索相似度阈值 */
    @Value("${ai.book.search-threshold:0.3}")
    private double bookSearchThreshold;

    /** 支持的文件后缀 */
    private static final Set<String> SUPPORTED_EXT = new HashSet<>(Arrays.asList("txt", "md", "markdown", "pdf"));
    /** 章节标题：第X章/节/篇，或 Markdown 标题 */
    private static final Pattern CHAPTER_PATTERN = Pattern.compile("^(第[一二三四五六七八九十百零\\d]+[章节篇].*|#{1,4}\\s+.+)$");
    /** 文件名非法字符（保留中文、字母数字、点、横线、下划线） */
    private static final Pattern UNSAFE_NAME = Pattern.compile("[^\\u4e00-\\u9fa5A-Za-z0-9._-]");

    @Autowired
    private BizBookContentMapper bookContentMapper;
    @Autowired
    private BizBookMapper bookMapper;
    @Autowired
    @Qualifier("customRedisVectorStore")
    private VectorStore vectorStore;

    /** 原文件落盘目录：在线浏览（PDF 内嵌预览）依赖它 */
    @Value("${ai.book.storage-dir:./data/book-files}")
    private String storageDir;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public BizBookContent uploadAndParse(Long bookId, MultipartFile file)
    {
        if (bookId == null)
        {
            throw new ServiceException("图书ID不能为空");
        }
        if (file == null || file.isEmpty())
        {
            throw new ServiceException("上传文件不能为空");
        }
        BizBook book = bookMapper.selectBizBookById(bookId);
        if (book == null)
        {
            throw new ServiceException("图书不存在：" + bookId);
        }

        String originalName = StringUtils.isNotEmpty(file.getOriginalFilename())
                ? file.getOriginalFilename() : "content.txt";
        String ext = originalName.contains(".")
                ? originalName.substring(originalName.lastIndexOf('.') + 1).toLowerCase() : "";
        if (!SUPPORTED_EXT.contains(ext))
        {
            throw new ServiceException("只支持 txt / md / pdf 文件，当前文件类型：" + ext);
        }

        byte[] bytes;
        try
        {
            bytes = file.getBytes();
        }
        catch (Exception e)
        {
            throw new IllegalStateException("读取文件失败：" + e.getMessage(), e);
        }

        // 1. 抽取正文：pdf 走 PDFBox。扫描件常抽不出文字，此时不报错，
        //    降级为「仅可在线预览、AI 不可问答」，否则用户传扫描版教材会直接被拒。
        String text;
        boolean pdfNoText = false;
        if ("pdf".equals(ext))
        {
            text = extractPdfText(bytes).replace("\r\n", "\n").trim();
            pdfNoText = text.isEmpty();
        }
        else
        {
            text = new String(bytes, StandardCharsets.UTF_8).replace("\r\n", "\n").trim();
            if (text.isEmpty())
            {
                throw new ServiceException("文件内容为空");
            }
        }

        BizBookContent existing = bookContentMapper.selectContentByBookId(bookId);
        int oldChunkCount = bookContentMapper.countChunksByBookId(bookId);
        String oldFilePath = existing == null ? null : existing.getFilePath();

        List<BizBookChunk> chunks = pdfNoText ? Collections.emptyList() : splitToChunks(bookId, text);

        // 1. 清理旧分片（重新上传即全量覆盖）
        bookContentMapper.deleteChunksByBookId(bookId);
        // 2. 分片入库，每 200 条一批，避免单条 SQL 过长
        for (int i = 0; i < chunks.size(); i += 200)
        {
            bookContentMapper.batchInsertChunks(chunks.subList(i, Math.min(i + 200, chunks.size())));
        }
        // 3. 写入向量库（文档ID固定为 book-{bookId}-{chunkNo}，重复上传自动覆盖）
        if (!chunks.isEmpty())
        {
            addToVectorStore(book, chunks);
        }
        // 4. 分片变少时旧的向量不会被覆盖，必须显式删除，否则会检索到已不存在的正文
        removeStaleVectors(bookId, chunks.size(), oldChunkCount);

        // 5. 原文件落盘（在线浏览依赖它）；写入失败抛运行时异常，DB 事务回滚
        File rawFile = writeRawFile(bookId, bytes, originalName);
        // 新文件写成功后再删旧文件，避免中途失败把旧的可预览文件也弄丢
        deleteQuietly(oldFilePath, rawFile.getAbsolutePath());

        // 6. 维护内容元信息
        BizBookContent content = existing != null ? existing : new BizBookContent();
        content.setBookId(bookId);
        content.setFileName(originalName);
        content.setFileType(ext);
        content.setFilePath(rawFile.getAbsolutePath());
        content.setCharCount(text.length());
        content.setChunkCount(chunks.size());
        if (pdfNoText)
        {
            content.setParseStatus(3);
            content.setParseMsg("PDF 未抽取出文本（可能是扫描件），仅支持在线预览，AI 暂无法据此问答");
        }
        else
        {
            content.setParseStatus(2);
            content.setParseMsg("解析成功：共 " + chunks.size() + " 个片段");
        }
        if (existing != null)
        {
            bookContentMapper.updateContent(content);
        }
        else
        {
            bookContentMapper.insertContent(content);
        }
        return content;
    }

    @Override
    public BizBookContent getContent(Long bookId)
    {
        return bookContentMapper.selectContentByBookId(bookId);
    }

    @Override
    public BookOutlineDTO getOutline(Long bookId)
    {
        BizBookContent content = bookContentMapper.selectContentByBookId(bookId);
        if (content == null)
        {
            return null;
        }
        BizBook book = bookMapper.selectBizBookById(bookId);
        List<BizBookChunk> outline = bookContentMapper.selectChunkOutline(bookId);
        List<BookOutlineDTO.ChapterDTO> chapters = new ArrayList<>(outline.size());
        for (BizBookChunk chunk : outline)
        {
            BookOutlineDTO.ChapterDTO item = new BookOutlineDTO.ChapterDTO();
            item.setChunkNo(chunk.getChunkNo());
            item.setChapter(StringUtils.isNotEmpty(chunk.getChapter())
                    ? chunk.getChapter() : "第 " + chunk.getChunkNo() + " 页");
            item.setCharCount(chunk.getCharCount());
            chapters.add(item);
        }
        BookOutlineDTO dto = new BookOutlineDTO();
        dto.setBookId(bookId);
        dto.setBookTitle(book == null ? null : book.getTitle());
        dto.setFileName(content.getFileName());
        dto.setFileType(content.getFileType());
        dto.setCharCount(content.getCharCount());
        dto.setChunkCount(content.getChunkCount());
        dto.setParseStatus(content.getParseStatus());
        dto.setParseMsg(content.getParseMsg());
        // PDF 且原文件还在，前端才用 iframe 内嵌预览
        dto.setPreviewable("pdf".equalsIgnoreCase(content.getFileType()) && resolveRawFile(content) != null);
        dto.setChapters(chapters);
        return dto;
    }

    @Override
    public BookChunkDTO readChunk(Long bookId, int chunkNo)
    {
        BizBookChunk chunk = bookContentMapper.selectChunkByNo(bookId, chunkNo);
        if (chunk == null)
        {
            return null;
        }
        BookChunkDTO dto = new BookChunkDTO();
        dto.setBookId(bookId);
        dto.setChunkNo(chunk.getChunkNo());
        dto.setChapter(chunk.getChapter());
        dto.setContent(chunk.getContent());
        dto.setCharCount(chunk.getCharCount());
        dto.setTotal(bookContentMapper.countChunksByBookId(bookId));
        return dto;
    }

    @Override
    public File getRawFile(Long bookId)
    {
        return resolveRawFile(bookContentMapper.selectContentByBookId(bookId));
    }

    /**
     * 解析 PDF 文本；加密或损坏时抛业务异常（提示用户而不是静默返回空）
     */
    private String extractPdfText(byte[] bytes)
    {
        try (PDDocument document = PDDocument.load(bytes))
        {
            if (document.isEncrypted())
            {
                throw new ServiceException("PDF 已加密，无法解析，请上传未加密的文件");
            }
            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setSortByPosition(true);
            return stripper.getText(document);
        }
        catch (ServiceException e)
        {
            throw e;
        }
        catch (Exception e)
        {
            throw new IllegalStateException("解析 PDF 失败：" + e.getMessage(), e);
        }
    }

    /**
     * 原文件落盘：{storageDir}/{bookId}/{时间戳}_{安全文件名}
     * 用时间戳前缀避免同名覆盖，同时保留原始文件名便于用户识别。
     */
    private File writeRawFile(Long bookId, byte[] bytes, String originalName)
    {
        String safeName = UNSAFE_NAME.matcher(originalName).replaceAll("_");
        File dir = new File(new File(storageDir), String.valueOf(bookId));
        try
        {
            Files.createDirectories(dir.toPath());
            File target = new File(dir, System.currentTimeMillis() + "_" + safeName);
            Files.write(target.toPath(), bytes);
            return target;
        }
        catch (IOException e)
        {
            throw new IllegalStateException("保存原文件失败：" + e.getMessage(), e);
        }
    }

    /** 删除旧原文件；路径为空或与新文件相同则跳过，失败只记日志不影响主流程 */
    private void deleteQuietly(String oldPath, String newPath)
    {
        if (!StringUtils.hasText(oldPath))
        {
            return;
        }
        try
        {
            File old = new File(oldPath).getCanonicalFile();
            File current = new File(newPath).getCanonicalFile();
            if (old.getPath().equals(current.getPath()))
            {
                return;
            }
            if (old.isFile() && old.delete())
            {
                log.info("已删除旧书籍原文件：" + old.getPath());
            }
        }
        catch (IOException e)
        {
            log.info("删除旧书籍原文件失败：" + e.getMessage());
        }
    }

    /**
     * 校验并返回可读的原文件。
     * 必须做「规范化路径 + 前缀校验」，否则 filePath 一旦被污染就能读到磁盘任意文件。
     */
    private File resolveRawFile(BizBookContent content)
    {
        if (content == null || !StringUtils.hasText(content.getFilePath()))
        {
            return null;
        }
        try
        {
            File root = new File(storageDir).getCanonicalFile();
            File file = new File(content.getFilePath()).getCanonicalFile();
            if (!file.getPath().startsWith(root.getPath() + File.separator))
            {
                log.info("书籍原文件路径越界，拒绝访问：" + file.getPath());
                return null;
            }
            return file.isFile() ? file : null;
        }
        catch (IOException e)
        {
            return null;
        }
    }

    /**
     * 删除重新上传后多余的向量：旧分片 5 个、新分片 3 个时，book-x-4/5 会残留，
     * 检索命中它们会拿到已不存在的正文，所以必须按 ID 显式删除。
     */
    private void removeStaleVectors(Long bookId, int newCount, int oldCount)
    {
        if (oldCount <= newCount)
        {
            return;
        }
        List<String> staleIds = new ArrayList<>();
        for (int no = newCount + 1; no <= oldCount; no++)
        {
            staleIds.add("book-" + bookId + "-" + no);
        }
        try
        {
            vectorStore.delete(staleIds);
            log.info("已清理重新上传后的残留向量：" + staleIds.size() + " 条");
        }
        catch (Exception e)
        {
            // 向量清理失败不影响本次上传（正文与分片已正确覆盖），仅提示
            log.info("清理残留向量失败（可忽略）：" + e.getMessage());
        }
    }

    @Override
    public List<Document> searchBookChunks(String question, int topK)
    {
        if (!StringUtils.hasText(question))
        {
            return Collections.emptyList();
        }
        // 因为 type 没进索引 schema，无法用 filter，只能放大 topK 后内存过滤
        SearchRequest request = SearchRequest.builder()
                .query(question)
                .topK(Math.max(topK * 8, 40))
                .similarityThreshold(bookSearchThreshold)
                .build();
        List<Document> docs = vectorStore.similaritySearch(request);
        if (docs == null || docs.isEmpty())
        {
            return Collections.emptyList();
        }
        // 注意：RedisVectorStore 检索回来时只会回填索引 schema 里声明的 metadata
        // （当前只有 knowledgeId / answer），type / bookId 会丢失。
        // 因此用文档ID前缀 book-{bookId}-{chunkNo} 判定是否为书籍片段，再回查书名补齐。
        //
        // 多本书都上传过正文时，不同书的片段会互相挤占 topK：问《星海纪事》的情节，
        // 命中里可能混进《Java 编程思想》的片段，模型拿到"半本 A 半本 B"就会答非所问
        // （实测出现过明明命中 3 个片段却回"暂时无法解答"）。
        // 这里先按书分组算相关度，再取前 2 本、每本最多 2 个片段，每段带书名交给模型判断。
        Map<Long, List<Document>> byBook = new LinkedHashMap<>();
        Map<Long, Double> bestScore = new HashMap<>();
        for (Document doc : docs)
        {
            String id = doc.getId();
            if (id == null || !id.startsWith("book-"))
            {
                continue;
            }
            Long bookId = parseBookIdFromDocId(id);
            if (bookId == null)
            {
                continue;
            }
            byBook.computeIfAbsent(bookId, k -> new ArrayList<>()).add(doc);
            double score = doc.getScore() == null ? 0D : doc.getScore();
            bestScore.merge(bookId, score, Math::max);
        }
        if (byBook.isEmpty())
        {
            return Collections.emptyList();
        }
        List<Document> matched = new ArrayList<>();
        // 按书的相关度排序，取前 3 本、每本最多 2 个片段：
        // 只取 1 本会漏（正确内容所在的书记录少、单条得分略低时被另一本挤掉，实测偶发答非所问）；
        // 取前 3 本能覆盖"小书库全量参与竞争"的常见情况，又不至于把rompt塞满。
        List<Map.Entry<Long, Double>> ranked = new ArrayList<>(bestScore.entrySet());
        ranked.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));
        int maxBooks = Math.min(3, ranked.size());
        int maxChunks = Math.max(6, topK * 2);
        for (int i = 0; i < maxBooks && matched.size() < maxChunks; i++)
        {
            Long bookId = ranked.get(i).getKey();
            BizBook book = bookMapper.selectBizBookById(bookId);
            String title = (book == null || book.getTitle() == null) ? "" : book.getTitle();
            int taken = 0;
            for (Document doc : byBook.get(bookId))
            {
                if (taken >= 2 || matched.size() >= maxChunks)
                {
                    break;
                }
                doc.getMetadata().put("bookTitle", title);
                doc.getMetadata().put("bookId", String.valueOf(bookId));
                matched.add(doc);
                taken++;
            }
        }
        return matched;
    }

    /** 从 book-{bookId}-{chunkNo} 解析 bookId */
    private Long parseBookIdFromDocId(String docId)
    {
        String[] parts = docId.split("-");
        if (parts.length < 3)
        {
            return null;
        }
        try
        {
            return Long.valueOf(parts[1]);
        }
        catch (NumberFormatException e)
        {
            return null;
        }
    }

    /**
     * 按 500 字滑窗分片，尽量在句号处断开。
     * 章节记录「分片起始章节 ~ 分片结束章节」：单个分片可能跨多章，
     * 只记最后一个标题会误导引用来源（例如事实在第二章、却标注成第三章）。
     */
    private List<BizBookChunk> splitToChunks(Long bookId, String text)
    {
        List<BizBookChunk> chunks = new ArrayList<>();
        int len = text.length();
        int start = 0;
        int no = 1;
        List<ChapterMark> marks = collectChapters(text);
        while (start < len)
        {
            int end = Math.min(start + chunkSize, len);
            if (end < len)
            {
                int stop = text.lastIndexOf('。', end);
                // 至少在半个窗口之后才接受句号断点，避免分片过短
                if (stop > start + chunkSize / 2)
                {
                    end = stop + 1;
                }
            }
            String piece = text.substring(start, end).trim();
            if (!piece.isEmpty())
            {
                BizBookChunk chunk = new BizBookChunk();
                chunk.setBookId(bookId);
                chunk.setChunkNo(no);
                chunk.setChapter(chapterOf(start, end, marks));
                chunk.setContent(piece);
                chunk.setCharCount(piece.length());
                chunk.setVectorId("book-" + bookId + "-" + no);
                chunks.add(chunk);
                no++;
            }
            if (end >= len)
            {
                break;
            }
            // 前移时回退一段做重叠；+1 兜底防止死循环
            start = Math.max(end - chunkOverlap, start + 1);
        }
        return chunks;
    }

    /** 章节标记：标题在全文中的起始偏移 + 标题文本 */
    private static class ChapterMark
    {
        private final int pos;
        private final String title;

        ChapterMark(int pos, String title)
        {
            this.pos = pos;
            this.title = title;
        }
    }

    /** 扫描全文中的章节标题（按出现位置升序） */
    private List<ChapterMark> collectChapters(String text)
    {
        List<ChapterMark> marks = new ArrayList<>();
        int offset = 0;
        for (String line : text.split("\n", -1))
        {
            String t = line.trim();
            if (!t.isEmpty() && t.length() <= 40 && CHAPTER_PATTERN.matcher(t).matches())
            {
                marks.add(new ChapterMark(offset, t.replaceAll("^#+\\s*", "")));
            }
            // +1 补回被 split 掉的换行符，保证 offset 与全文下标对齐
            offset += line.length() + 1;
        }
        return marks;
    }

    /**
     * 计算分片 [start, end) 的章节：
     * 起始章节 = start 之前（含）最后一个标题；若分片内还有后续标题，则记录为「起 ~ 止」。
     */
    private String chapterOf(int start, int end, List<ChapterMark> marks)
    {
        String atStart = null;
        String lastInside = null;
        for (ChapterMark m : marks)
        {
            if (m.pos <= start)
            {
                atStart = m.title;
            }
            if (m.pos < end)
            {
                lastInside = m.title;
            }
            else
            {
                break;
            }
        }
        String first = atStart != null ? atStart : lastInside;
        if (first == null)
        {
            return null;
        }
        if (lastInside != null && !lastInside.equals(first))
        {
            return first + " ~ " + lastInside;
        }
        return first;
    }

    /** 分批写入向量库，metadata 带 type/bookId/bookTitle/chunkNo/chapter */
    private void addToVectorStore(BizBook book, List<BizBookChunk> chunks)
    {
        List<Document> batch = new ArrayList<>(vectorBatch);
        for (BizBookChunk chunk : chunks)
        {
            Map<String, Object> metadata = new HashMap<>();
            metadata.put("type", "book");
            metadata.put("bookId", String.valueOf(book.getBookId()));
            metadata.put("bookTitle", book.getTitle() == null ? "" : book.getTitle());
            metadata.put("chunkNo", String.valueOf(chunk.getChunkNo()));
            if (chunk.getChapter() != null)
            {
                metadata.put("chapter", chunk.getChapter());
            }
            String docText = (chunk.getChapter() == null ? "" : chunk.getChapter() + "\n") + chunk.getContent();
            batch.add(new Document(chunk.getVectorId(), docText, metadata));
            if (batch.size() >= vectorBatch)
            {
                vectorStore.add(new ArrayList<>(batch));
                batch.clear();
            }
        }
        if (!batch.isEmpty())
        {
            vectorStore.add(batch);
        }
    }
}
