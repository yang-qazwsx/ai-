-- ----------------------------
-- 业务模块：图书管理 + 订单管理（可重复执行）
-- ----------------------------

CREATE TABLE IF NOT EXISTS `biz_book` (
  `book_id`     bigint       NOT NULL AUTO_INCREMENT COMMENT '图书ID',
  `isbn`        varchar(32)  DEFAULT NULL            COMMENT 'ISBN',
  `title`       varchar(200) NOT NULL               COMMENT '书名',
  `author`      varchar(100) DEFAULT NULL            COMMENT '作者',
  `publisher`   varchar(100) DEFAULT NULL            COMMENT '出版社',
  `price`       decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT '定价',
  `stock`       int          NOT NULL DEFAULT 0      COMMENT '库存',
  `category`    varchar(50)  DEFAULT NULL            COMMENT '分类',
  `status`      char(1)      NOT NULL DEFAULT '1'    COMMENT '状态（0下架 1上架）',
  `description` varchar(500) DEFAULT NULL            COMMENT '简介',
  `create_time` datetime     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`book_id`),
  KEY `idx_book_title` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='图书信息表';

CREATE TABLE IF NOT EXISTS `biz_order` (
  `order_id`   bigint       NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `order_no`   varchar(64)  NOT NULL               COMMENT '订单号',
  `user_id`    bigint       DEFAULT NULL            COMMENT '用户ID',
  `book_id`    bigint       DEFAULT NULL            COMMENT '关联图书ID',
  `book_title` varchar(200) DEFAULT NULL            COMMENT '图书名称快照',
  `quantity`   int          NOT NULL DEFAULT 1      COMMENT '数量',
  `amount`     decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT '订单金额',
  `status`     char(1)      NOT NULL DEFAULT '0'    COMMENT '状态（0待付款 1待发货 2已发货 3已完成 4已退款）',
  `receiver`   varchar(50)  DEFAULT NULL            COMMENT '收货人',
  `phone`      varchar(20)  DEFAULT NULL            COMMENT '联系电话',
  `address`    varchar(255) DEFAULT NULL            COMMENT '收货地址',
  `remark`     varchar(500) DEFAULT NULL            COMMENT '备注',
  `create_time` datetime    NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_order_status` (`status`),
  KEY `idx_order_book` (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='订单信息表';

-- ----------------------------
-- 示例数据
-- ----------------------------
INSERT INTO `biz_book` (`book_id`, `isbn`, `title`, `author`, `publisher`, `price`, `stock`, `category`, `status`, `description`)
SELECT 1, '9787111641247', '深入理解计算机系统', 'Randal E. Bryant', '机械工业出版社', 139.00, 25, '计算机', '1', '从程序员视角讲解计算机系统底层原理'
WHERE NOT EXISTS (SELECT 1 FROM `biz_book` WHERE `book_id` = 1);
INSERT INTO `biz_book` (`book_id`, `isbn`, `title`, `author`, `publisher`, `price`, `stock`, `category`, `status`, `description`)
SELECT 2, '9787111213826', 'Java 编程思想', 'Bruce Eckel', '机械工业出版社', 108.00, 12, '计算机', '1', 'Java 语言经典入门与进阶读物'
WHERE NOT EXISTS (SELECT 1 FROM `biz_book` WHERE `book_id` = 2);
INSERT INTO `biz_book` (`book_id`, `isbn`, `title`, `author`, `publisher`, `price`, `stock`, `category`, `status`, `description`)
SELECT 3, '9787020002207', '红楼梦', '曹雪芹', '人民文学出版社', 59.70, 40, '文学', '1', '中国古典四大名著之一'
WHERE NOT EXISTS (SELECT 1 FROM `biz_book` WHERE `book_id` = 3);

INSERT INTO `biz_order` (`order_id`, `order_no`, `user_id`, `book_id`, `book_title`, `quantity`, `amount`, `status`, `receiver`, `phone`, `address`)
SELECT 1, 'BO202611110001', 1, 1, '深入理解计算机系统', 1, 139.00, '2', '张三', '13800138000', '北京市海淀区中关村大街1号'
WHERE NOT EXISTS (SELECT 1 FROM `biz_order` WHERE `order_id` = 1);
INSERT INTO `biz_order` (`order_id`, `order_no`, `user_id`, `book_id`, `book_title`, `quantity`, `amount`, `status`, `receiver`, `phone`, `address`)
SELECT 2, 'BO202611110002', 1, 3, '红楼梦', 2, 119.40, '1', '李四', '13900139000', '上海市浦东新区世纪大道100号'
WHERE NOT EXISTS (SELECT 1 FROM `biz_order` WHERE `order_id` = 2);

-- ----------------------------
-- 智能客服知识库：订单 / 图书常见问答
-- ----------------------------
INSERT INTO `ai_knowledge` (`question`, `answer`, `category`, `hit_count`, `create_time`, `update_time`)
SELECT '订单多久发货', '普通图书下单付款后 48 小时内发货，预售商品按商品页标注时间发货，节假日顺延。可在订单管理中查看订单状态，1 表示待发货、2 表示已发货。', '订单问题', 0, sysdate(), sysdate()
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `ai_knowledge` WHERE `question` = '订单多久发货');
INSERT INTO `ai_knowledge` (`question`, `answer`, `category`, `hit_count`, `create_time`, `update_time`)
SELECT '如何查询订单状态', '进入「业务管理 - 订单管理」，可按订单号、收货人、状态筛选。状态含义：0 待付款、1 待发货、2 已发货、3 已完成、4 已退款。', '订单问题', 0, sysdate(), sysdate()
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `ai_knowledge` WHERE `question` = '如何查询订单状态');
INSERT INTO `ai_knowledge` (`question`, `answer`, `category`, `hit_count`, `create_time`, `update_time`)
SELECT '如何申请退款', '在订单管理中找到对应订单，联系客服提交退款申请；审核通过后 3-7 个工作日原路退回，订单状态会变为 4（已退款）。', '订单问题', 0, sysdate(), sysdate()
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `ai_knowledge` WHERE `question` = '如何申请退款');
INSERT INTO `ai_knowledge` (`question`, `answer`, `category`, `hit_count`, `create_time`, `update_time`)
SELECT '如何查询图书库存', '进入「业务管理 - 图书管理」，可按书名、作者、ISBN、分类筛选，列表中的「库存」列即为当前可售数量。', '图书问题', 0, sysdate(), sysdate()
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `ai_knowledge` WHERE `question` = '如何查询图书库存');
INSERT INTO `ai_knowledge` (`question`, `answer`, `category`, `hit_count`, `create_time`, `update_time`)
SELECT '图书如何上架下架', '在图书管理中编辑对应图书，把「状态」改为 1（上架）或 0（下架）后保存即可。下架的图书不再对外展示。', '图书问题', 0, sysdate(), sysdate()
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `ai_knowledge` WHERE `question` = '图书如何上架下架');

-- ----------------------------
-- 菜单（menu_id 2100~2199，避开现有最大 2004）
-- ----------------------------
DELETE FROM `sys_role_menu` WHERE `menu_id` BETWEEN 2100 AND 2199;
DELETE FROM `sys_menu` WHERE `menu_id` BETWEEN 2100 AND 2199;

INSERT INTO `sys_menu` (`menu_id`,`menu_name`,`parent_id`,`order_num`,`path`,`component`,`is_frame`,`is_cache`,`menu_type`,`visible`,`status`,`perms`,`icon`,`create_by`,`create_time`,`remark`) VALUES
(2100,'业务管理',0,5,'biz',NULL,1,0,'M','0','0','','build','admin',sysdate(),'业务管理目录'),
(2101,'订单管理',2100,1,'order','biz/order/index',1,0,'C','0','0','biz:order:list','shopping','admin',sysdate(),''),
(2102,'订单查询',2101,1,'',NULL,1,0,'F','0','0','biz:order:query','#','admin',sysdate(),''),
(2103,'订单新增',2101,2,'',NULL,1,0,'F','0','0','biz:order:add','#','admin',sysdate(),''),
(2104,'订单修改',2101,3,'',NULL,1,0,'F','0','0','biz:order:edit','#','admin',sysdate(),''),
(2105,'订单删除',2101,4,'',NULL,1,0,'F','0','0','biz:order:remove','#','admin',sysdate(),''),
(2110,'图书管理',2100,2,'book','biz/book/index',1,0,'C','0','0','biz:book:list','education','admin',sysdate(),''),
(2111,'图书查询',2110,1,'',NULL,1,0,'F','0','0','biz:book:query','#','admin',sysdate(),''),
(2112,'图书新增',2110,2,'',NULL,1,0,'F','0','0','biz:book:add','#','admin',sysdate(),''),
(2113,'图书修改',2110,3,'',NULL,1,0,'F','0','0','biz:book:edit','#','admin',sysdate(),''),
(2114,'图书删除',2110,4,'',NULL,1,0,'F','0','0','biz:book:remove','#','admin',sysdate(),'');

-- 分配给超级管理员角色（role_id = 1）
INSERT INTO `sys_role_menu` (`role_id`,`menu_id`)
SELECT 1, `menu_id` FROM `sys_menu` WHERE `menu_id` BETWEEN 2100 AND 2199;
