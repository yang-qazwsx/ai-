-- ============================================================
-- 图书全文索引（中文 ngram）
--
-- 目的：把「有红楼梦卖吗 / 有恐龙的书吗」这类检索从
--       LIKE '%关键词%' 全表扫描，升级为倒排索引匹配。
--
-- 为什么用 ngram 解析器：MySQL 默认分词器按空格切词，中文整句会被当成
-- 一个词，`MATCH ... AGAINST('恐龙')` 永远命中不了。ngram 按 2 字切片
-- （ngram_token_size=2），中文才能正常检索。
--
-- 覆盖列：title / category / description
--   - title：精确书名（红楼梦）
--   - category：品类（计算机、文学、科幻）
--   - description：简介里的主题词（如"儿童科普"）
--   注意 MATCH() 的列顺序必须与索引列一致，否则报 "Can't find FULLTEXT index matching the column list"。
--
-- 幂等：索引已存在则跳过，可重复执行。
-- 执行库：ry-cloud
-- ============================================================

SET @idx_exists := (
    SELECT COUNT(*) FROM information_schema.statistics
    WHERE table_schema = DATABASE()
      AND table_name = 'biz_book'
      AND index_name = 'ft_book_search'
);

SET @ddl := IF(@idx_exists = 0,
    'ALTER TABLE `biz_book` ADD FULLTEXT INDEX `ft_book_search` (`title`, `category`, `description`) WITH PARSER ngram',
    'SELECT ''ft_book_search already exists, skip'' AS msg');

PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 校验：确认索引已建立且类型为 FULLTEXT
SELECT index_name, column_name, index_type
FROM information_schema.statistics
WHERE table_schema = DATABASE() AND table_name = 'biz_book' AND index_name = 'ft_book_search'
ORDER BY seq_in_index;
