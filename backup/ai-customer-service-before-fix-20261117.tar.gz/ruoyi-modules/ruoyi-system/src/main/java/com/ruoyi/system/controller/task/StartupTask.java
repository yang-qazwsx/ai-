package com.ruoyi.system.controller.task;

import com.alibaba.nacos.api.ai.AiService;
import com.ruoyi.system.service.IAiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class StartupTask  implements ApplicationRunner {

    @Autowired
    private IAiService iAiService;
    @Override
    public void run(ApplicationArguments args) throws Exception {
        iAiService.initKnowledgeVector();
    }
}
