package com.ruoyi.system.service.impl;

import java.util.Collections;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.common.core.exception.ServiceException;
import com.ruoyi.common.core.utils.StringUtils;
import com.ruoyi.system.domain.AiKnowledge;
import com.ruoyi.system.mapper.AiKnowledgeMapper;
import com.ruoyi.system.service.IAiKnowledgeService;

/**
 * AI 问答知识库 服务层实现
 *
 * @author ruoyi
 */
@Service
public class AiKnowledgeServiceImpl implements IAiKnowledgeService
{
    @Autowired
    private AiKnowledgeMapper aiKnowledgeMapper;

    @Override
    public AiKnowledge selectAiKnowledgeById(Long id)
    {
        return aiKnowledgeMapper.selectAiKnowledgeById(id);
    }

    @Override
    public List<AiKnowledge> selectAiKnowledgeList(AiKnowledge aiKnowledge)
    {
        return aiKnowledgeMapper.selectPageByCategory(aiKnowledge);
    }

    @Override
    public List<AiKnowledge> searchByKeyword(String keyword)
    {
        if (StringUtils.isEmpty(keyword))
        {
            return Collections.emptyList();
        }
        return aiKnowledgeMapper.selectByKeyword(keyword.trim());
    }

    @Override
    public int increaseHitCount(List<Long> ids)
    {
        if (ids == null || ids.isEmpty())
        {
            return 0;
        }
        return aiKnowledgeMapper.batchUpdateHitCount(ids);
    }

    @Override
    public int insertAiKnowledge(AiKnowledge aiKnowledge)
    {
        // question / answer / category 在表中都是非空且无默认值
        if (aiKnowledge == null || StringUtils.isEmpty(aiKnowledge.getQuestion())
                || StringUtils.isEmpty(aiKnowledge.getAnswer())
                || StringUtils.isEmpty(aiKnowledge.getCategory()))
        {
            throw new ServiceException("问题、答案和分类不能为空");
        }
        if (aiKnowledge.getHitCount() == null)
        {
            aiKnowledge.setHitCount(0);
        }
        return aiKnowledgeMapper.insertAiKnowledge(aiKnowledge);
    }

    @Override
    public int updateAiKnowledge(AiKnowledge aiKnowledge)
    {
        if (aiKnowledge == null || aiKnowledge.getId() == null)
        {
            throw new ServiceException("知识库ID不能为空");
        }
        return aiKnowledgeMapper.updateAiKnowledge(aiKnowledge);
    }

    @Override
    public int deleteAiKnowledgeByIds(Long[] ids)
    {
        return aiKnowledgeMapper.deleteAiKnowledgeByIds(ids);
    }
}
