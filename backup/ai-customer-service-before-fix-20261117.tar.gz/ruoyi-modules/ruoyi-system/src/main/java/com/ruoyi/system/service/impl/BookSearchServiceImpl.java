package com.ruoyi.system.service.impl;

import com.ruoyi.system.domain.BizBook;
import com.ruoyi.system.mapper.BizBookMapper;
import com.ruoyi.system.search.EsBookSearchClient;
import com.ruoyi.system.service.IBookSearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 图书检索服务实现
 *
 * 一致性策略：MySQL 是事实源，ES 只做检索。
 *   - 写入：图书增删改后同步索引（失败只记日志，不影响业务）
 *   - 读取：先从 ES 拿 bookId，再回 MySQL 查实时价格/库存
 *     （价格与库存变动频繁，直接从 ES 取会展示过期数据）
 * 降级：ES 不可用时 searchBookIds 返回 null，调用方落回 MySQL 全文/LIKE 检索。
 *
 * @author ruoyi
 */
@Service
public class BookSearchServiceImpl implements IBookSearchService
{
    private static final Logger log = LoggerFactory.getLogger(BookSearchServiceImpl.class);
    @Autowired
    private EsBookSearchClient searchClient;

    @Autowired
    private BizBookMapper bookMapper;

    /** 启动时索引为空则自动全量同步一次 */
    @Value("${ai.book.search.bootstrap-on-start:true}")
    private boolean bootstrapOnStart;

    @Override
    public boolean isEnabled()
    {
        return searchClient.isEnabled();
    }

    @Override
    public List<Long> searchBookIds(String keyword, boolean onSaleOnly, int limit)
    {
        if (!searchClient.isEnabled())
        {
            return null;
        }
        try
        {
            return searchClient.searchIds(keyword, onSaleOnly, limit);
        }
        catch (Exception e)
        {
            // 连接异常时 message 常为 null，补上异常类型便于排查
            log.info("ES 检索失败，降级 MySQL：" + e.getClass().getSimpleName()
                    + (e.getMessage() == null ? "" : " - " + e.getMessage()));
            return null;
        }
    }

    @Override
    public void syncBook(BizBook book)
    {
        if (!searchClient.isEnabled() || book == null || book.getBookId() == null)
        {
            return;
        }
        try
        {
            searchClient.ensureIndex();
            searchClient.indexBook(book);
        }
        catch (Exception e)
        {
            // 索引同步失败不能影响图书增删改本身，等下次全量重建补回
            log.info("同步图书索引失败（可稍后重建）：bookId=" + book.getBookId() + "，原因：" + e.getMessage());
        }
    }

    @Override
    public void deleteBook(Long bookId)
    {
        if (!searchClient.isEnabled() || bookId == null)
        {
            return;
        }
        try
        {
            searchClient.deleteBook(bookId);
        }
        catch (Exception e)
        {
            log.info("删除图书索引失败（可稍后重建）：bookId=" + bookId + "，原因：" + e.getMessage());
        }
    }

    @Override
    public int reindexAll()
    {
        List<BizBook> books = bookMapper.selectBizBookList(new BizBook());
        try
        {
            searchClient.recreateIndex();
            int count = searchClient.bulkIndex(books);
            log.info("图书索引重建完成：共 " + count + " 条");
            return count;
        }
        catch (Exception e)
        {
            throw new IllegalStateException("重建图书索引失败：" + e.getMessage(), e);
        }
    }

    @Override
    public Map<String, Object> status()
    {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("enabled", searchClient.isEnabled());
        map.put("index", searchClient.getIndexName());
        boolean reachable = searchClient.isEnabled() && searchClient.ping();
        map.put("reachable", reachable);
        if (reachable)
        {
            try
            {
                map.put("docCount", searchClient.count());
            }
            catch (Exception e)
            {
                map.put("docCount", -1);
            }
        }
        return map;
    }

    /**
     * 启动时初始化：ES 可达且索引为空则全量同步。
     * 用独立线程跑，避免大书库拖慢启动；失败只打日志，功能自动降级 MySQL。
     */
    @EventListener(ApplicationReadyEvent.class)
    public void bootstrapIndex()
    {
        if (!searchClient.isEnabled() || !bootstrapOnStart)
        {
            return;
        }
        Thread thread = new Thread(() -> {
            try
            {
                if (!searchClient.ping())
                {
                    log.info("ES 不可达（" + searchClient.getIndexName() + "），图书检索将降级 MySQL");
                    return;
                }
                searchClient.ensureIndex();
                long count = searchClient.count();
                if (count <= 0)
                {
                    reindexAll();
                }
                else
                {
                    log.info("图书索引已存在，文档数：" + count);
                }
            }
            catch (Exception e)
            {
                log.info("初始化图书索引失败（将降级 MySQL）：" + e.getMessage());
            }
        }, "es-book-bootstrap");
        thread.setDaemon(true);
        thread.start();
    }
}
