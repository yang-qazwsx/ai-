-- ============================================================
-- 图书内容问答 + 用户长期记忆/画像 建表脚本
-- 执行库：ry-cloud
-- 幂等：建表用 IF NOT EXISTS；加列/加索引用 information_schema 判断
-- ============================================================

-- 1. 书籍内容文件（一本书一份正文，重新上传即覆盖）
CREATE TABLE IF NOT EXISTS `biz_book_content` (
  `id`           BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  `book_id`      BIGINT       NOT NULL COMMENT '图书ID',
  `file_name`    VARCHAR(255) NOT NULL COMMENT '原始文件名',
  `file_path`    VARCHAR(500) DEFAULT NULL COMMENT '存储路径或URL',
  `file_type`    VARCHAR(20)  DEFAULT NULL COMMENT 'txt/md/pdf',
  `char_count`   INT          DEFAULT 0 COMMENT '正文总字数',
  `chunk_count`  INT          DEFAULT 0 COMMENT '分片数量',
  `parse_status` TINYINT      DEFAULT 0 COMMENT '0待解析 1解析中 2成功 3失败',
  `parse_msg`    VARCHAR(500) DEFAULT NULL COMMENT '解析失败原因或摘要',
  `create_time`  DATETIME     DEFAULT CURRENT_TIMESTAMP,
  `update_time`  DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_book` (`book_id`),
  KEY `idx_parse_status` (`parse_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='书籍内容文件';

-- 2. 书籍正文分片（向量库的正文来源，便于重建与回溯）
CREATE TABLE IF NOT EXISTS `biz_book_chunk` (
  `id`         BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  `book_id`    BIGINT       NOT NULL COMMENT '图书ID',
  `chunk_no`   INT          NOT NULL COMMENT '分片序号，从1开始',
  `chapter`    VARCHAR(200) DEFAULT NULL COMMENT '所属章节（能识别时填写）',
  `content`    TEXT         NOT NULL COMMENT '片段正文',
  `char_count` INT          DEFAULT 0 COMMENT '片段字数',
  `vector_id`  VARCHAR(100) DEFAULT NULL COMMENT '向量库文档ID',
  `create_time` DATETIME    DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_book_chunk` (`book_id`, `chunk_no`),
  KEY `idx_book` (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='书籍内容分片';

-- 3. 用户长期记忆（LLM 抽取的结构化记忆）
CREATE TABLE IF NOT EXISTS `ai_user_memory` (
  `id`               BIGINT        NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id`          BIGINT        NOT NULL COMMENT '用户ID',
  `memory_type`      VARCHAR(32)   NOT NULL COMMENT 'preference/fact/event/concern',
  `content`          VARCHAR(1000) NOT NULL COMMENT '记忆内容（一句话）',
  `keywords`         VARCHAR(255)  DEFAULT NULL COMMENT '关键词，逗号分隔',
  `vector_id`        VARCHAR(100)  DEFAULT NULL COMMENT '向量库文档ID',
  `confidence`       DECIMAL(3,2)  DEFAULT 0.80 COMMENT '置信度',
  `source_record_id` BIGINT        DEFAULT NULL COMMENT '来源对话记录ID',
  `hit_count`        INT           DEFAULT 0 COMMENT '被召回次数',
  `last_hit_time`    DATETIME      DEFAULT NULL COMMENT '最近一次被召回时间',
  `create_time`      DATETIME      DEFAULT CURRENT_TIMESTAMP,
  `update_time`      DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_type` (`user_id`, `memory_type`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户长期记忆';

-- 4. 用户画像（聚合结果，注入 Prompt 用）
CREATE TABLE IF NOT EXISTS `ai_user_profile` (
  `id`                   BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id`              BIGINT       NOT NULL COMMENT '用户ID',
  `tags`                 VARCHAR(500) DEFAULT NULL COMMENT '画像标签，逗号分隔',
  `preferred_categories` VARCHAR(255) DEFAULT NULL COMMENT '关注品类',
  `preferred_books`      VARCHAR(500) DEFAULT NULL COMMENT '关注图书',
  `total_questions`      INT          DEFAULT 0 COMMENT '累计提问数',
  `total_sessions`       INT          DEFAULT 0 COMMENT '累计会话数',
  `last_active_time`     DATETIME     DEFAULT NULL COMMENT '最近活跃时间',
  `profile_summary`      VARCHAR(1000) DEFAULT NULL COMMENT '画像摘要（注入Prompt）',
  `create_time`          DATETIME     DEFAULT CURRENT_TIMESTAMP,
  `update_time`          DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户画像';

-- 5. ai_chat_record 增加 session_id（多轮会话），幂等处理
SET @col_exists := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ai_chat_record' AND COLUMN_NAME = 'session_id'
);
SET @ddl := IF(@col_exists = 0,
  'ALTER TABLE `ai_chat_record` ADD COLUMN `session_id` VARCHAR(64) DEFAULT NULL COMMENT ''会话ID'' AFTER `user_id`',
  'SELECT ''session_id already exists''');
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 6. 会话检索索引，幂等处理
SET @idx_exists := (
  SELECT COUNT(*) FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ai_chat_record' AND INDEX_NAME = 'idx_session'
);
SET @ddl2 := IF(@idx_exists = 0,
  'ALTER TABLE `ai_chat_record` ADD KEY `idx_session` (`session_id`)',
  'SELECT ''idx_session already exists''');
PREPARE stmt2 FROM @ddl2; EXECUTE stmt2; DEALLOCATE PREPARE stmt2;

-- 7. 按用户+时间查最近对话的索引
SET @idx2_exists := (
  SELECT COUNT(*) FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ai_chat_record' AND INDEX_NAME = 'idx_user_time'
);
SET @ddl3 := IF(@idx2_exists = 0,
  'ALTER TABLE `ai_chat_record` ADD KEY `idx_user_time` (`user_id`, `chat_time`)',
  'SELECT ''idx_user_time already exists''');
PREPARE stmt3 FROM @ddl3; EXECUTE stmt3; DEALLOCATE PREPARE stmt3;

-- 校验
SELECT TABLE_NAME, TABLE_COMMENT FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME IN ('biz_book_content','biz_book_chunk','ai_user_memory','ai_user_profile');
SELECT COLUMN_NAME FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='ai_chat_record' AND COLUMN_NAME='session_id';
