-- ============================================================
-- 把「智谱大模型 / 智能客服」配置注入 Nacos 配置中心
-- dataId : ruoyi-system-ai-dev.yml   group : DEFAULT_GROUP
-- 幂等   : 重复执行只更新 content/md5，不会产生重复行
--
-- 适用前提：Nacos 使用 MySQL 持久化且已初始化 ry-config 库。
--           若 Nacos 是内嵌存储，请改用控制台粘贴 sql/ruoyi-system-ai-dev.yml。
-- 【部署前必做】把下面第 1 行的占位符替换成你的真实智谱 API Key。
-- 执行后重启 ruoyi-system 生效（Spring AI 的 Bean 启动时构建）。
-- ============================================================

USE `ry-config`;

SET @zhipu_key = '__ZHIPU_API_KEY__';

SET @ai_content_raw = '# ============================================================\n# dataId : ruoyi-system-ai-dev.yml\n# group  : DEFAULT_GROUP\n# 用途   : 智谱大模型 / Spring AI / 智能客服调优参数，由 Nacos 注入\n# 加载方 : ruoyi-system 的 application.yml -> spring.config.import\n# 注意   : 修改后需重启 ruoyi-system。Spring AI 的 ChatModel /\n#          EmbeddingModel 在启动时构建，Nacos 动态刷新不会重建这些 Bean。\n#\n# 【部署前必做】把下面的 __ZHIPU_API_KEY__ 替换成你的真实 Key。\n# ============================================================\n\nspring:\n  ai:\n    openai:\n      api-key: __ZHIPU_API_KEY__\n      # 智谱 OpenAI 兼容端点必须带 /v4，否则 SDK 会拼出 /api/paas/embeddings（404）\n      base-url: "https://open.bigmodel.cn/api/paas/v4"\n      # Spring AI 2.0 用扁平属性，不再走 1.x 的 .options 段\n      chat:\n        # glm-4.5 是思考型模型，单次生成实测约 13s；\n        # glm-4-flash 为免费快模型，约 1~3s，做知识库答案润色质量足够\n        model: "glm-4-flash"\n      embedding:\n        model: "embedding-3"\n        dimensions: 256\n\n  http:\n    client:\n      # 外网调用读超时，用于容忍网络抖动；快模型通常 1~3s 返回\n      read-timeout: 100000\n\n# 智能客服「知识库直达」参数：命中后跳过调用大模型，直接返回知识库标准答案\nai:\n  chat:\n    # 相似度安全阀。端到端实测：相关问法召回分数 0.81~0.86，\n    # 不相关问题（如「图书可以货到付款吗」）也能拿到 0.8024，\n    # 所以 0.80 会误判；设 0.92 让该分支几乎不参与判定。\n    # 主力直达判定是 AiServiceImpl.findDirectAnswer 的「归一化文本匹配」。\n    direct-similarity-threshold: 0.92\n    direct-text-match-enabled: true\n';
SET @ai_content = REPLACE(@ai_content_raw, '__ZHIPU_API_KEY__', @zhipu_key);

INSERT INTO `config_info`
  (`data_id`, `group_id`, `content`, `md5`, `gmt_create`, `gmt_modified`,
   `src_user`, `src_ip`, `app_name`, `tenant_id`, `c_desc`, `c_use`, `effect`, `type`, `c_schema`, `encrypted_data_key`)
VALUES
  ('ruoyi-system-ai-dev.yml', 'DEFAULT_GROUP', @ai_content, MD5(@ai_content), NOW(), NOW(),
   'nacos', '127.0.0.1', '', '', '智谱大模型与智能客服配置', 'null', 'null', 'yaml', '', '')
ON DUPLICATE KEY UPDATE
  `content` = @ai_content,
  `md5` = MD5(@ai_content),
  `gmt_modified` = NOW();

SELECT `data_id`, `group_id`, `md5`, `gmt_modified`
FROM `config_info` WHERE `data_id` = 'ruoyi-system-ai-dev.yml';
