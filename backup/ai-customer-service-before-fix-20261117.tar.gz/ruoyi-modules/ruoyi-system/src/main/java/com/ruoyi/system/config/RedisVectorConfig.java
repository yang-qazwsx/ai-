package com.ruoyi.system.config;

import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.ai.vectorstore.redis.RedisVectorStore;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.StringRedisTemplate;
import redis.clients.jedis.RedisClient;

import java.nio.charset.StandardCharsets;

/**
 * Redis 向量库配置
 *
 * @author ruoyi
 */
@Configuration
public class RedisVectorConfig {

    @Bean
    public RedisClient jedisClient() {
        return RedisClient.builder().build();
    }

    @Bean
    public VectorStore customRedisVectorStore(RedisClient jedisClient,StringRedisTemplate redisTemplate, EmbeddingModel embeddingModel) {
        // 1. 先检查索引是否已存在
        boolean indexExists = checkIndexExists(redisTemplate, "aa_rag_index");

        return RedisVectorStore.builder(jedisClient, embeddingModel)
                .indexName("aa_rag_index")
                .prefix("aa_rag_prefix")
                .initializeSchema(!indexExists)   // 关键：存在则 false，不存在则 true
                .metadataFields(
                        RedisVectorStore.MetadataField.tag("knowledgeId"),
                        RedisVectorStore.MetadataField.text("answer")
                )
                .build();
    }
    /**
     * 通过 FT.INFO 判断索引是否存在
     * 索引不存在时 Redis 会返回错误（unknown index name），捕获后返回 false
     */
    private boolean checkIndexExists(StringRedisTemplate redisTemplate, String indexName) {
        return Boolean.TRUE.equals(
                redisTemplate.execute((RedisCallback<Boolean>) connection -> {
                    try {
                        connection.execute("FT.INFO",
                                indexName.getBytes(StandardCharsets.UTF_8));
                        return true;   // 命令成功 = 索引存在
                    } catch (Exception e) {
                        return false;  // 报错 = 索引不存在
                    }
                })
        );
    }

}
