package com.ruoyi.system.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.nacos.shaded.com.google.common.collect.Maps;
import com.github.pagehelper.Page;
import com.ruoyi.common.core.exception.ServiceException;
import com.ruoyi.common.core.utils.StringUtils;
import com.ruoyi.system.domain.*;
import com.ruoyi.system.mapper.AiChatRecordMapper;
import com.ruoyi.system.mapper.AiIntentMapper;
import com.ruoyi.system.mapper.AiKnowledgeMapper;
import com.ruoyi.system.mapper.BizBookMapper;
import com.ruoyi.system.mapper.BizOrderMapper;
import com.ruoyi.system.service.IAiBookContentService;
import com.ruoyi.system.service.IAiMemoryService;
import com.ruoyi.system.service.IBookSearchService;
import com.ruoyi.system.service.IAiService;
import org.apache.commons.compress.utils.Lists;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * AI 对话记录 服务层实现
 *
 * 职责分区（本类较大，按分区定位）：
 *   1. 核心流程          —— handleUserQuestion 主链路
 *   2. 热门缓存          —— cacheHotAnswer / isCacheableForHotPool
 *   3. 图书在售查询       —— answerStockQuery 及辅助（describeStock 等）
 *   4. 图书推荐          —— recommendBooks 及辅助（预算解析/真实性校验/确定性兜底）
 *   5. 书名校验兜底       —— guardHallucinatedTitles / isChapterLike
 *   6. 订单号直达         —— queryOrderStatus / orderStatusText
 *   7. 意图识别          —— recognizeIntent
 *   8. 归一化/工具        —— normalizeQuestion / containsAny / logCost 等
 *
 * @author ruoyi
 */
@Service
public class AiServiceImpl implements IAiService
{
    private static final Logger log = LoggerFactory.getLogger(AiServiceImpl.class);


    // 热门问题缓存：Hash 的 field=归一化问题、value=答案；ZSet 记录热度排行。
    // DISPLAY 保存「归一化 key -> 首次提问原文」，供热门问题列表展示可读文案。
    // 旧数据（field 直接是原文）没有 DISPLAY 记录，读取时退回 member 本身，保持兼容。
    private static final String HOT_QUESTION_DETAIL_KEY = "hot:question:detail";
    private static final String HOT_QUESTION_RANK_KEY = "hot:question:rank";
    private static final String HOT_QUESTION_DISPLAY_KEY = "hot:question:display";

    /** 订单号候选：字母/数字开头、长度 8~32 的连续串，如 BO202611110001 */
    private static final Pattern ORDER_NO_PATTERN = Pattern.compile("[A-Za-z0-9][A-Za-z0-9_-]{7,31}");

    /** 归一化时要剔除的：所有空白 + 中英文标点 */
    private static final Pattern NOISE_PATTERN =
            Pattern.compile("[\\s\\p{Punct}，。！？；：、‘’“”（）《》【】…—·~]+");

    /** 归一化时要剔除的客套/语气词，长的排前面，避免「请问一下」被「请问」先切成「一下」 */
    private static final String[] FILLER_WORDS = {
            "麻烦问一下", "请问一下", "帮我查一下", "我想问一下", "想知道一下",
            "查一下", "看一下", "问一下", "打扰一下",
            "麻烦", "请问", "帮我", "我想问", "我想", "谢谢了", "谢谢",
            "一下", "的话", "呢", "吗", "啊", "呀", "哈", "咯", "呗"
    };

    /** 常见疑问词同义归一：让「怎么申请退款」「如何申请退款」收敛到同一 key */
    private static final String[][] SYNONYMS = {
            {"怎么样", "如何"}, {"怎样", "如何"}, {"怎么", "如何"}, {"咋", "如何"},
            {"啥时候", "多久"}, {"什么时候", "多久"}, {"多长时间", "多久"},
            {"可不可以", "是否"}, {"是否可以", "是否"}, {"能不能", "是否"}
    };

    /** 「查」->「查询」，但排除「查询」本身和「检查/调查/审查/搜查」等实义词 */
    private static final Pattern CHA_PATTERN = Pattern.compile("(?<![检调审搜])查(?!询)");

    @Autowired
    private  AiKnowledgeMapper knowledgeMapper;
    @Autowired
    private  AiIntentMapper intentMapper;
    @Autowired
    private  AiChatRecordMapper chatRecordMapper;
    @Autowired
    @Qualifier("customRedisVectorStore")
    private  VectorStore vectorStore;
    @Autowired
    private  ChatClient chatClient;
    @Autowired
    private  StringRedisTemplate redisTemplate;
    @Autowired
    private  PlatformTransactionManager transactionManager;
    @Autowired
    private  BizOrderMapper bizOrderMapper;
    @Autowired
    private  IAiBookContentService bookContentService;
    @Autowired
    private  IAiMemoryService memoryService;
    @Autowired
    private  BizBookMapper bizBookMapper;
    @Autowired
    private  IBookSearchService bookSearchService;

    /** 相似度直达阈值（安全阀），见 application.yml 的 ai.chat.direct-similarity-threshold */
    @Value("${ai.chat.direct-similarity-threshold:0.80}")
    private double directSimilarityThreshold;

    /** 是否启用「归一化文本匹配」直达（主力判定） */
    @Value("${ai.chat.direct-text-match-enabled:true}")
    private boolean directTextMatchEnabled;

    /** 向量检索相似度阈值（召回门槛） */
    @Value("${ai.chat.search-similarity-threshold:0.5}")
    private double searchSimilarityThreshold;

    /** 向量检索 topK */
    @Value("${ai.chat.search-top-k:3}")
    private int searchTopK;

    /** 热门问题缓存过期秒数 */
    @Value("${ai.chat.hot-cache-expire-seconds:7200}")
    private long hotCacheExpireSeconds;

    /** 图书检索单次返回上限 */
    @Value("${ai.chat.stock-search-limit:50}")
    private int stockSearchLimit;

    // 大模型Prompt模板（结合知识库回答，确保回复精准）
    private static final String PROMPT_TEMPLATE = """
            你是一个专业的智能客服，根据以下参考资料回答用户问题：
            【用户画像与历史记忆】
            {userProfile}
            【参考资料】
            {knowledge}
            要求：
            1. 优先使用参考资料中的信息，不要编造；
            2. 参考【用户画像与历史记忆】调整称呼与推荐倾向，但不要直接复述用户隐私细节；
            3. 参考资料若包含【书籍原文片段】，请优先基于原文回答，并注明书名与章节；
               章节标注若形如「A ~ B」，必须完整引用该范围，不要只取 A 或 B；
               片段可能来自多本不同的书：**逐条判断**，只要某一条片段能回答问题就直接使用它作答
               （注明该片段所属书名），不要因为"它属于另一本书"就跳过，也不要把不同书的片段拼成一个答案；
            4. 如果参考资料完全没有相关内容，回复"非常抱歉，您的问题暂时无法解答，请联系人工客服"；
            5. 回复简洁明了，不要超过300字；
            6. 保持友好语气；
            7. 【用户画像与历史记忆】只用于调整称呼、语气与推荐倾向，**不代表店铺经营范围或在售商品**：
               在售商品、价格、库存一律以参考资料为准，绝不能因为用户偏好某类书就说"我们只卖这类书"；
               **也不要复述画像/记忆原文**（如"您平时只看科幻、预算两百"），更不要把用户偏好硬扯到当前问题上
               （问退款就答退款，不要说"在您的预算范围内退款"）。
            8. 不得编造书名与售价：回答中每个《书名》都必须在参考资料里出现过，价格必须与资料一致；
               若用户想买/想找的书不在资料里，直接说明"当前在售图书中没有这本书"，不要给出虚构书名或报价。
            用户问题：{question}
            """;

    /**
     * 兜底/否定话术标记：命中任意一个就说明没真正答上来，不能写进热门缓存。
     * 之前只认「暂时无法解答」，但模型会换说法（"未找到相关信息""无法回答"），
     * 导致否定答案被缓存后一直回放错误结果。
     */
    private static final String[] FALLBACK_MARKERS = {
            "暂时无法解答", "无法解答", "未找到相关信息", "未找到", "没有相关", "无法回答", "找不到相关"
    };

    /**
     * 「图书推荐」意图名（与 ai_intent 表一致）。
     *
     * 特征词职责边界（双份维护的说明）：
     *   - 意图识别（recognizeIntent）以 ai_intent 表 keywords 为唯一来源；
     *   - 下面的 RECOMMEND_HINTS / TASTE_HINTS / STOCK_HINTS 是**独立兜底**，
     *     在 guard 兜底阶段（isRecommendQuestion(question, null)）没有 intent 可用，
     *     必须靠这些词表自行判定，所以不能与表合并，只能保持同步；
     *   - 修改推荐/在售关键词时，需同时改 ai_intent 表与这里的词表，二者职责不同。
     */
    private static final String RECOMMEND_INTENT = "图书推荐";

    /** 推荐类问题特征词：命中即走库存结构化检索，不再走 FAQ 语义召回 */
    private static final String[] RECOMMEND_HINTS = {
            "推荐", "书单", "有什么书", "有哪些书", "买什么书", "看什么书", "适合读", "选书"
    };

    /**
     * 求推荐的口语化表达：与 BOOK_WORDS 同时出现才算推荐意图。
     * 覆盖"我平时只看科幻小说，预算两百"这类不含"推荐"二字的问法。
     */
    private static final String[] TASTE_HINTS = {
            "喜欢", "爱看", "爱读", "想看", "想买", "预算", "挑几本", "找几本", "适合我"
    };

    /** 「图书在售查询」分支标识（有卖吗/多少钱/有货吗，需要实时库存，不走向量检索） */
    private static final String STOCK_INTENT = "图书在售查询";

    /**
     * 在售类问法特征词：命中后若能识别出书名，直接用 biz_book 的真实价格/库存作答。
     * 这类问题必须实时查库——走大模型只会得到"可能有/可能没有"的臆断。
     */
    private static final String[] STOCK_HINTS = {
            "卖吗", "有卖", "有货", "卖不卖", "在售", "库存", "多少钱", "什么价", "价格",
            "能买", "怎么买", "买得到", "有没有"
    };

    /** 「有 X 书吗」形式：用于判断在售类问法，避免"有什么优惠"被误判成查库存 */
    private static final Pattern AVAILABILITY_PATTERN =
            Pattern.compile("有[^，。？?！!]{0,8}(书|图书|小说|读物|教材)");

    /** 图书分类缓存时长（分类变动低频，避免每句提问都查库） */
    private static final long CATEGORY_CACHE_MILLIS = 300_000L;

    private volatile List<String> categoryCache = new ArrayList<>();
    private volatile long categoryCacheAt = 0L;

    /** 提到这些词才算「图书类问题」，避免"退款要多少钱"被当成库存查询 */
    private static final String[] BOOK_WORDS = {"书", "图书", "书籍", "读物", "教材", "小说"};

    /**
     * 从「有恐龙书吗」这类问题里剥出主题词（恐龙），用于按主题匹配库存。
     * 顺序要在前，避免「有没有」被「有」先切掉。
     */
    private static final String[] TOPIC_STOP_WORDS = {
            "你们", "我们", "店里", "这里", "那里", "店里边", "请问",
            "有没有", "有卖", "在售", "卖不卖", "多少钱", "什么价", "价格", "能买", "怎么买", "买得到",
            "哪些", "什么", "看看", "卖", "买", "有", "吗", "呢", "么", "的", "类", "系列", "本", "书"
    };

    /**
     * 个性化问题标记：命中则不允许进入全局热门问题池。
     * hot:question:* 是全局 key、不分用户，若把"给孩子挑书，预算120"这类问答写进去，
     * A 用户的家庭情况与预算会被展示给所有人。
     */
    private static final String[] PERSONAL_MARKERS = {
            "我", "俺", "咱", "孩子", "儿子", "女儿", "家里", "家人", "预算", "岁",
            "生日", "推荐", "喜欢", "想要", "打算", "最近"
    };

    /** 从大模型回答里抽取《书名》与价格，用于真实性校验 */
    private static final Pattern TITLE_PATTERN = Pattern.compile("《([^》]{1,30})》");
    private static final Pattern PRICE_PATTERN = Pattern.compile("([0-9]+(?:\\.[0-9]+)?)\\s*(?:元|块)");

    /** 推荐 Prompt：只允许使用检索到的真实书单，禁止编造书名/价格 */
    private static final String RECOMMEND_PROMPT_TEMPLATE = """
            你是图书导购助手，只能使用下面【可推荐图书清单】里的数据回答，清单以外一律视为不存在。
            【可推荐图书清单】（书名 | 分类 | 价格 | 库存）
            {bookList}
            【用户画像与历史记忆】
            {userProfile}
            要求：
            1. 只能推荐清单中的图书，书名必须与清单完全一致，不得出现清单外的书名或作者；
            2. 价格与库存必须与清单一致，不得估算、不得编造；
            3. 推荐 2~3 本，逐条给出「书名 + 价格 + 一句话推荐理由」；
            4. 若清单为空，直接回复"当前没有符合条件的在售图书"；
            5. 若清单里的书明显不符合用户需求（年龄段、主题），必须如实说明"库存中没有完全匹配的图书"，
               可以列出作为参考，但不得声称它符合该需求；
            6. 不超过 200 字，语气友好。
            用户需求：{question}
            """;


    /**
     * 处理用户提问，核心流程：参数校验→订单号直达→归一化缓存→意图识别→向量检索
     * →知识库直达→（未命中才走）大模型生成→记录存储→写缓存
     */
    @Override
    public AiResponseDTO handleUserQuestion(UserQuestionDTO questionDTO) {
        long startTime = System.currentTimeMillis();
        AiResponseDTO responseDTO = new AiResponseDTO();
        String contextId = StringUtils.hasText(questionDTO.getContextId())
                ? questionDTO.getContextId()
                : UUID.randomUUID().toString();
        responseDTO.setContextId(contextId);

        try {
            // 1. 参数校验
            questionDTO.validate();
            Long userId = questionDTO.getUserId();
            String question = questionDTO.getQuestion();
//            log.info("处理用户提问：userId={}, question={}, contextId={}", userId, question, contextId);
            log.info("处理用户提问：userId=" + userId + ", question=" + question + ", contextId=" + contextId);
            // 提问计数与最近活跃时间（所有分支都计入）
            memoryService.touchProfile(userId);

            // 1.1 订单号直达：提问里带订单号时直接查库返回真实状态。
            //     故意放在热门缓存之前，保证状态实时；不走向量检索/大模型，也避免大模型编造数据。
            String orderAnswer = queryOrderStatus(question);
            if (orderAnswer != null) {
                responseDTO.setAnswer(orderAnswer);
                responseDTO.setIntent("查询订单");
                saveChatRecordAndUpdateKnowledge(userId, question, orderAnswer, Lists.newArrayList());
                responseDTO.setResponseTime(System.currentTimeMillis() - startTime);
                return responseDTO;
            }


            // 1.2 图书在售查询：问"有没有某本书/多少钱/有货吗"时直接查 biz_book。
            //     必须放在热门缓存之前——价格与库存是实时数据，且不能让历史错误答案继续复读；
            //     也不能走大模型：模型不知道库存，只会结合画像臆断（曾出现"红楼梦不在我们的
            //     恐龙科普书籍范围内"这种把用户偏好当成店铺经营范围的错误回答）。
            String stockAnswer = answerStockQuery(question);
            if (stockAnswer != null) {
                responseDTO.setAnswer(stockAnswer);
                responseDTO.setIntent(STOCK_INTENT);
                saveChatRecordAndUpdateKnowledge(userId, question, stockAnswer, Lists.newArrayList());
                memoryService.extractAndSaveAsync(userId, question, stockAnswer);
                responseDTO.setResponseTime(System.currentTimeMillis() - startTime);
                logCost(STOCK_INTENT, startTime);
                return responseDTO;
            }

            // 2. 热门问题缓存：key 用「归一化问题」而不是原始文本。
            //    "订单多久发货" / "请问订单多久发货呢？" / "订单多久发货?" 会命中同一条，
            //    避免换个说法就重新走一遍向量检索 + 大模型。
            String cacheKey = normalizeQuestion(question);
            Object cached = redisTemplate.opsForHash().get(HOT_QUESTION_DETAIL_KEY, cacheKey);
            if (cached != null) {
                // 命中：热度 +1，直接返回缓存答案，不再走意图识别/向量检索/大模型
                redisTemplate.opsForZSet().incrementScore(HOT_QUESTION_RANK_KEY, cacheKey, 1);
                responseDTO.setAnswer(cached.toString());
                responseDTO.setIntent("热门问题");
                responseDTO.setResponseTime(System.currentTimeMillis() - startTime);
                logCost("热门缓存命中", startTime);
                return responseDTO;
            }

            // 3. 意图识别
            String intent = recognizeIntent(question);
            responseDTO.setIntent(intent);
            // 记录算法真实结果：后面的直达/缓存分支会覆盖 intent，导致无法判断识别是否失败
            responseDTO.setRecognizedIntent(intent);
//            log.info("用户意图识别结果：intent={}", intent);
            log.info("用户意图识别结果：intent=" + intent);

            // 3.1 图书推荐：走库存结构化检索（biz_book 的真实价格/库存），
            //     不用 FAQ 语义召回——否则会把知识库条目当成书推荐，甚至编造书名与价格。
            if (isRecommendQuestion(question, intent)) {
                String recommendAnswer = recommendBooks(userId, question);
                responseDTO.setAnswer(recommendAnswer);
                responseDTO.setIntent(RECOMMEND_INTENT);
                saveChatRecordAndUpdateKnowledge(userId, question, recommendAnswer, Lists.newArrayList());
                memoryService.extractAndSaveAsync(userId, question, recommendAnswer);
                // 推荐包含用户偏好，属于个性化问答，不写入全局热门池
                responseDTO.setResponseTime(System.currentTimeMillis() - startTime);
                logCost("图书推荐", startTime);
                return responseDTO;
            }


            

            // 4. 构建 SearchRequest，相似度阈值直接交给向量库/框架处理
            // 智谱 embedding-3（256维）实测：中文问句与知识库文档的余弦相似度
            // 最高约 0.65（如「如何修改密码？」= 0.649、「账号问题」= 0.646），
            // 原来的 0.7 会把所有结果过滤掉；0.5 能保留相关项，同时挡掉明显无关的条目。
            SearchRequest searchRequest = SearchRequest.builder()
                    .query(question)
                    .topK(searchTopK)
                    .similarityThreshold(searchSimilarityThreshold)
                    .build();

            // similaritySearch 直接返回 List<Document>，不再有 SearchResult 包装
            List<Document> documents = vectorStore.similaritySearch(searchRequest);

            List<AiResponseDTO.KnowledgeDTO> relatedKnowledges = Lists.newArrayList();
            List<Long> knowledgeIds = Lists.newArrayList();

            if (!CollectionUtils.isEmpty(documents)) {
                for (Document doc : documents) {
                    // 3. 分数直接从 Document 上取，不再需要 result.getScore()
                    Double score = doc.getScore();
                    if (score == null) {
                        continue;               // 部分向量库实现可能不返回 score，做防御性判断
                    }

                    Object knowledgeIdObj = doc.getMetadata().get("knowledgeId");
                    if (knowledgeIdObj == null) {
                        continue;
                    }
                    Long knowledgeId = Long.valueOf(knowledgeIdObj.toString());

                    AiKnowledge knowledge = knowledgeMapper.selectAiKnowledgeById(knowledgeId);
                    if (!ObjectUtils.isEmpty(knowledge)) {
                        AiResponseDTO.KnowledgeDTO knowledgeDTO = new AiResponseDTO.KnowledgeDTO();
                        BeanUtils.copyProperties(knowledge, knowledgeDTO);
                        knowledgeDTO.setSimilarity(score.floatValue());  // Double → Float，保持原 DTO 字段类型
                        relatedKnowledges.add(knowledgeDTO);
                        knowledgeIds.add(knowledgeId);
                    }
                }
            }

            responseDTO.setRelatedKnowledges(relatedKnowledges);

            log.info("向量检索知识库结果：knowledgeIds=" + knowledgeIds
                    + " similarity=" + relatedKnowledges.stream()
                    .map(AiResponseDTO.KnowledgeDTO::getSimilarity).collect(Collectors.toList()));

            // 5. 知识库直达：命中明确答案时跳过调用大模型，直接返回标准答案。
            //    这是把 FAQ 类问题从 ~15s 压到 ~1s（仅剩外网 Embedding）的关键分支。
            //    判定优先级：归一化文本匹配（准） > 相似度阈值（安全阀）。
            AiResponseDTO.KnowledgeDTO direct = findDirectAnswer(question, relatedKnowledges);
            if (direct != null) {
                String directAnswer = direct.getAnswer();
                responseDTO.setAnswer(directAnswer);
                responseDTO.setIntent("知识库直达");
                List<Long> directIds = Lists.newArrayList();
                if (direct.getId() != null) {
                    directIds.add(direct.getId());
                }
                saveChatRecordAndUpdateKnowledge(userId, question, directAnswer, directIds);
                // 直达答案同样进缓存，下一次同类问法连 Embedding 都省掉
                cacheHotAnswer(question, directAnswer);
                responseDTO.setResponseTime(System.currentTimeMillis() - startTime);
                logCost("知识库直达", startTime);
                return responseDTO;
            }

            // 6. 构造大模型Prompt：知识库问答对 + 书籍原文片段
            String knowledgeContent = CollectionUtils.isEmpty(relatedKnowledges)
                    ? "无相关知识库内容"
                    : relatedKnowledges.stream()
                    .map(k -> String.format("问题：%s，答案：%s", k.getQuestion(), k.getAnswer()))
                    .collect(Collectors.joining("；"));

            // 书籍正文检索：命中后作为【书籍原文片段】补充，实现"问书籍内容"
            List<Document> bookChunks = bookContentService.searchBookChunks(question, 3);
            if (!CollectionUtils.isEmpty(bookChunks)) {
                knowledgeContent = knowledgeContent + "\n\n" + formatBookChunks(bookChunks);
                log.info("书籍正文命中片段数：" + bookChunks.size());
            }

            Map<String, Object> promptParams = Maps.newHashMap();
            promptParams.put("knowledge", knowledgeContent);
            promptParams.put("question", question);
            // 用户画像 + 长期记忆（最近 + 语义召回）
            String userContext = memoryService.buildUserContext(userId, question);
            promptParams.put("userProfile", StringUtils.hasText(userContext) ? userContext : "无（新用户或暂无记忆）");
            if (StringUtils.hasText(userContext)) {
                log.info("注入用户画像/记忆：" + userContext.replace("\n", " "));
            }



            long llmStart = System.currentTimeMillis();
            String aiAnswer = chatClient.prompt()
                    .user(u -> u.text(PROMPT_TEMPLATE).params(promptParams))
                    .call()
                    .content();  // 2.0 中 .content() 是获取最终字符串的标准方式
            logCost("大模型生成", llmStart);

            // 最后一道防线：模型可能绕过"不要编造"的约束，提到库里不存在的书名+价格。
            // 一旦发现，改走结构化推荐（只列真实在售图书），绝不让编造内容落到用户面前。
            aiAnswer = guardHallucinatedTitles(userId, question, aiAnswer);

            responseDTO.setAnswer(aiAnswer);
            log.info("大模型生成回复：answer=" + aiAnswer);

            // 7. 编程式事务：保存对话记录+更新知识库命中次数
            saveChatRecordAndUpdateKnowledge(userId, question, aiAnswer, knowledgeIds);

            // 7.1 异步抽取长期记忆并刷新画像，不阻塞用户响应
            memoryService.extractAndSaveAsync(userId, question, aiAnswer);

            // 8. 写入热门问题缓存：只缓存「确实答上来」的知识库通用问答。
            //    - 不看书籍命中：书内容问答是具体篇章问题，不属于「热门常见问题」；
            //    - cacheHotAnswer 内部还会过滤个性化问题，避免把用户隐私写进全局池。
            boolean hasKnowledgeHit = !CollectionUtils.isEmpty(relatedKnowledges);
            if (hasKnowledgeHit && StringUtils.hasText(aiAnswer) && !isFallbackAnswer(aiAnswer)) {
                cacheHotAnswer(question, aiAnswer);
            }

        } catch (ServiceException e) {
            // 参数校验失败：交给全局异常处理器返回 code=500，
            // 不要把错误文案塞进 answer（前端会当成答案渲染）。
            log.info("参数校验失败：" + e.getMessage());
            throw e;
        } catch (Exception e) {
//            log.error("处理用户提问异常：", e);
            log.info("处理用户提问异常："+ e);
            responseDTO.setAnswer("非常抱歉，服务异常，请稍后再试");
        }

        // 9. 计算响应时间
        responseDTO.setResponseTime(System.currentTimeMillis() - startTime);
        logCost("本次问答总耗时(" + responseDTO.getIntent() + ")", startTime);
        return responseDTO;
    }



    /**
     * 从 Redis 读取热门问题。
     * 数据来源：热度排行 ZSet（hot:question:rank，member=归一化问题 key，score=命中次数，取 TopN）
     * 关联答案：答案 Hash（hot:question:detail，field=归一化 key，value=答案）。
     * 关联展示：hot:question:display（field=归一化 key，value=首次提问原文），缺失时退回 key。
     * 注：热门问题由 handleUserQuestion 在「确实答上来」时自动写入并累加热度，
     * 因此冷启动（无人提问）时列表为空，前端应做空态展示。
     *
     * @param limit 返回条数上限
     * @return 热门问题列表
     */
    @Override
    public List<AiHotQuestionDTO> getHotQuestions(int limit) {
        List<AiHotQuestionDTO> result = new ArrayList<>();
        if (limit <= 0) {
            limit = 10;
        }
        // 1. 从热度 ZSet 取 TopN（分数从高到低）
        Set<ZSetOperations.TypedTuple<String>> tuples =
                redisTemplate.opsForZSet().reverseRangeWithScores(HOT_QUESTION_RANK_KEY, 0, limit - 1);
        if (tuples == null || tuples.isEmpty()) {
            return result;
        }
        // 2. 逐条关联答案 Hash，组装 DTO
        for (ZSetOperations.TypedTuple<String> tuple : tuples) {
            String key = tuple.getValue();   // 归一化 key（历史数据可能就是原文）
            if (!StringUtils.hasText(key)) {
                continue;
            }
            Object answerObj = redisTemplate.opsForHash().get(HOT_QUESTION_DETAIL_KEY, key);
            // 跳过答案缺失的脏数据（正常流程下每个热度成员都有对应答案），
            // 避免前端展示空答案；命中知识库的问答会重新写入答案自愈。
            if (answerObj == null) {
                continue;
            }
            // 展示用首次提问原文；旧数据无 display 记录时退回 key 本身，保持兼容
            Object displayObj = redisTemplate.opsForHash().get(HOT_QUESTION_DISPLAY_KEY, key);
            String display = (displayObj == null || !StringUtils.hasText(displayObj.toString()))
                    ? key : displayObj.toString();
            Double score = tuple.getScore();
            AiHotQuestionDTO dto = new AiHotQuestionDTO();
            dto.setQuestion(display);
            dto.setAnswer(answerObj.toString());
            dto.setHitCount(score == null ? 0L : score.longValue());
            result.add(dto);
        }
        return result;
    }

    /**
     * 问题归一化：把「请问订单多久发货呢？」「订单多久发货!」收敛成同一个 key。
     * 全角转半角 -> 转小写 -> 去客套/语气词 -> 去所有标点与空白。
     * 纯本地字符串运算，不额外调 Embedding，因此放在缓存查询最前面不会拖慢快路径。
     */
    private String normalizeQuestion(String question) {
        if (!StringUtils.hasText(question)) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (char c : question.trim().toCharArray()) {
            if (c >= 0xFF01 && c <= 0xFF5E) {
                sb.append((char) (c - 0xFEE0));      // 全角 ASCII -> 半角
            } else if (c == 0x3000) {
                sb.append(' ');                       // 全角空格
            } else {
                sb.append(c);
            }
        }
        String s = sb.toString().toLowerCase();
        for (String filler : FILLER_WORDS) {
            s = s.replace(filler, "");
        }
        s = NOISE_PATTERN.matcher(s).replaceAll("");
        // 疑问词同义归一（轻量语义缓存）：只统一虚词，不动实义词，避免把不同问题合并
        for (String[] pair : SYNONYMS) {
            s = s.replace(pair[0], pair[1]);
        }
        s = CHA_PATTERN.matcher(s).replaceAll("查询");
        // 极端情况：整句被当成客套词削空时退回紧凑原文，避免所有问题挤到同一个 key
        return StringUtils.hasText(s) ? s : question.trim().toLowerCase();
    }

    /**
     * 知识库直达判定。命中即直接返回知识库标准答案，跳过大模型。
     * 为什么以文本匹配为主：embedding-3 是 256 维，中文近义问句与文档的余弦相似度
     * 实测最高只有约 0.65，用 0.85 之类的阈值永远不会触发；而归一化文本匹配
     * 对 FAQ 场景既准又零成本。相似度阈值只作为「问法完全一致」时的安全阀。
     *
     * @return 命中的知识库条目，未命中返回 null
     */
    private AiResponseDTO.KnowledgeDTO findDirectAnswer(String question,
            List<AiResponseDTO.KnowledgeDTO> candidates) {
        if (CollectionUtils.isEmpty(candidates)) {
            return null;
        }
        // A. 归一化文本匹配（主力）
        if (directTextMatchEnabled) {
            String nq = normalizeQuestion(question);
            if (nq.length() >= 4) {
                for (AiResponseDTO.KnowledgeDTO k : candidates) {
                    String nk = normalizeQuestion(k.getQuestion());
                    if (nk.length() < 4) {
                        continue;
                    }
                    // 长度差过大不做包含判定，避免「A 和 B 一起问」被短条目误命中
                    boolean closeLen = Math.abs(nq.length() - nk.length()) <= 6;
                    if (nq.equals(nk) || (closeLen && (nq.contains(nk) || nk.contains(nq)))) {
                        return k;
                    }
                }
            }
        }
        // B. 相似度阈值（安全阀）：取分数最高的一条
        AiResponseDTO.KnowledgeDTO best = null;
        double bestScore = -1;
        for (AiResponseDTO.KnowledgeDTO k : candidates) {
            Float sc = k.getSimilarity();
            if (sc != null && sc > bestScore) {
                bestScore = sc;
                best = k;
            }
        }
        return (best != null && bestScore >= directSimilarityThreshold) ? best : null;
    }

    /**
     * 写入热门问题缓存：归一化 key 存答案，display Hash 存首次提问原文供列表展示，
     * rank ZSet 累加热度。三个 key 统一 TTL，避免展示文案比答案活得更久。
     */
    private void cacheHotAnswer(String question, String answer) {
        if (!isCacheableForHotPool(question) || !StringUtils.hasText(answer)) {
            return;
        }
        String key = normalizeQuestion(question);
        redisTemplate.opsForHash().put(HOT_QUESTION_DETAIL_KEY, key, answer);
        redisTemplate.opsForHash().putIfAbsent(HOT_QUESTION_DISPLAY_KEY, key, question);
        redisTemplate.opsForZSet().incrementScore(HOT_QUESTION_RANK_KEY, key, 1);
        for (String redisKey : new String[]{HOT_QUESTION_DETAIL_KEY, HOT_QUESTION_DISPLAY_KEY, HOT_QUESTION_RANK_KEY}) {
            Long ttl = redisTemplate.getExpire(redisKey, TimeUnit.SECONDS);
            if (ttl == null || ttl < 0) {
                redisTemplate.expire(redisKey, hotCacheExpireSeconds, TimeUnit.SECONDS);
            }
        }
    }

    /**
     * 全局热门问题池的准入判断：只收「通用型」问答。
     * 全局池不分用户，个性化问题（含"我/孩子/预算/推荐"等）写入后会把用户隐私展示给所有人，
     * 因此这类问题不缓存、不进排行，下次照常走正常链路。
     */
    private boolean isCacheableForHotPool(String question) {
        if (!StringUtils.hasText(question)) {
            return false;
        }
        String q = question.trim();
        if (q.length() < 4 || q.length() > 60) {
            return false;
        }
        for (String marker : PERSONAL_MARKERS) {
            if (q.contains(marker)) {
                return false;
            }
        }
        return true;
    }

    /**
     * 「这本书有卖吗 / 多少钱 / 有没有某类书」：查 biz_book 实时作答，不调大模型。
     * 返回 null 表示这不是图书在售类问题，交回主流程。
     */
    private String answerStockQuery(String question) {
        if (!StringUtils.hasText(question)) {
            return null;
        }
        // 先做廉价判断（纯字符串匹配），避免每句提问都去查库
        if (!isAvailabilityQuestion(question)) {
            return null;
        }
        Matcher quotedMatcher = TITLE_PATTERN.matcher(question);
        String quoted = quotedMatcher.find() ? quotedMatcher.group(1).trim() : null;
        boolean hasBookWord = containsAny(question, BOOK_WORDS);
        String topic = extractTopic(question);
        // 检索关键词：点名书名就用书名；否则用剥出来的主题词；泛问（"有书吗"）为空
        String keyword = StringUtils.hasText(quoted) ? quoted : topic;

        List<BizBook> books = searchBooks(keyword);
        if (CollectionUtils.isEmpty(books)) {
            if (StringUtils.hasText(quoted)) {
                return "抱歉，书库里没有《" + quoted + "》这本书，可以在图书列表看看其他在售图书。";
            }
            if (hasBookWord && StringUtils.hasText(topic)) {
                return "暂时没有与「" + topic + "」相关的在售图书，可以换个说法，或在图书列表页浏览全部图书。";
            }
            // 如"退款要多少钱"：既没有图书线索、也检索不到书，交回正常链路
            return null;
        }

        // A. 点名了书名（《X》）
        if (StringUtils.hasText(quoted)) {
            for (BizBook book : books) {
                if (titleMatches(book.getTitle(), quoted)) {
                    return describeStock(book);
                }
            }
            return "抱歉，书库里没有《" + quoted + "》这本书，可以在图书列表看看其他在售图书。";
        }
        // 问题里直接包含某本书名（"红楼梦卖吗"不含"书"字，靠这里兜住）
        BizBook hit = longestTitleInQuestion(question, books);
        if (hit != null) {
            return describeStock(hit);
        }
        if (!hasBookWord) {
            return null;
        }

        // B. 没点名书名：列出检索到的真实在售图书
        List<BizBook> onSale = new ArrayList<>();
        for (BizBook book : books) {
            if ("1".equals(book.getStatus())) {
                onSale.add(book);
            }
        }
        if (onSale.isEmpty()) {
            return StringUtils.hasText(topic)
                    ? "暂时没有与「" + topic + "」相关的在售图书，可以换个说法，或在图书列表页浏览全部图书。"
                    : "当前没有在售图书。";
        }
        return buildStockListAnswer(topic, onSale);
    }

    /**
     * 图书检索：全文索引优先，未命中再用 LIKE 兜底。
     * 为什么必须兜底：中文 ngram 分词对「中英混排里的英文词」会漏检——
     * 实测 "Java 编程思想" 用 MATCH('Java') 命中 0 条，而 LIKE '%Java%' 正常。
     */
    private List<BizBook> searchBooks(String keyword) {
        if (!StringUtils.hasText(keyword)) {
            return bizBookMapper.selectOnSaleBooks(stockSearchLimit);
        }
        // ES 优先：倒排索引，且 bigram 分词能覆盖英文词（MySQL ngram 会漏 "Java"）
        List<BizBook> esResult = searchByEs(keyword);
        if (!CollectionUtils.isEmpty(esResult)) {
            return esResult;
        }
        // 降级：ES 未启用 / 不可用 / 未命中，走 MySQL 全文索引 + LIKE
        // BOOLEAN MODE 里 + - * " ( ) ~ < > 是语法字符，先清掉，避免改变检索语义
        String ftKeyword = keyword.replaceAll("[+\\-*\"()~<>]", " ").trim();
        List<BizBook> rows = new ArrayList<>();
        if (StringUtils.hasText(ftKeyword)) {
            try {
                rows = bizBookMapper.searchBookByFulltext(ftKeyword, stockSearchLimit);
            } catch (Exception e) {
                // 索引未建（未执行 sql/biz_book_fulltext_index.sql）时降级，不影响功能可用性
                log.info("全文检索不可用，降级 LIKE：" + e.getMessage());
            }
        }
        if (CollectionUtils.isEmpty(rows)) {
            String likeKeyword = keyword.replace("%", "").replace("_", "");
            if (StringUtils.hasText(likeKeyword)) {
                rows = bizBookMapper.searchBookByLike(likeKeyword, stockSearchLimit);
            }
        }
        return rows;
    }

    /**
     * ES 检索：ES 只返回 bookId，价格/库存回 MySQL 取实时值。
     * 为什么不在 ES 里直接取价格库存：改价、下单扣库存后 ES 会滞后，
     * 检索做“找哪些书”，事实数据仍以库为准。
     *
     * @return null 表示 ES 不可用或未命中，由调用方降级 MySQL
     */
    private List<BizBook> searchByEs(String keyword) {
        if (!bookSearchService.isEnabled()) {
            return null;
        }
        List<Long> ids = bookSearchService.searchBookIds(keyword, false, stockSearchLimit);
        if (CollectionUtils.isEmpty(ids)) {
            return null;
        }
        List<BizBook> rows = bizBookMapper.selectBooksByIds(ids);
        if (CollectionUtils.isEmpty(rows)) {
            return null;
        }
        // 按 ES 相关度顺序还原（MySQL IN 查询不保证顺序）
        Map<Long, BizBook> byId = new HashMap<>(rows.size());
        for (BizBook book : rows) {
            byId.put(book.getBookId(), book);
        }
        List<BizBook> ordered = new ArrayList<>(rows.size());
        for (Long id : ids) {
            BizBook book = byId.get(id);
            if (book != null) {
                ordered.add(book);
            }
        }
        log.info("ES 检索命中：" + ordered.size() + " 本，关键词=" + keyword);
        return ordered;
    }

    /** 是否在问「有没有/卖不卖/多少钱」：命中原有特征词，或「卖/有X书」+ 疑问语气 */
    private boolean isAvailabilityQuestion(String question) {
        if (containsAny(question, STOCK_HINTS)) {
            return true;
        }
        boolean askTone = question.contains("吗") || question.contains("么")
                || question.contains("?") || question.contains("？");
        if (!askTone) {
            return false;
        }
        if (question.contains("卖")) {
            return true;
        }
        // 只认「有…书/小说」或「有…（已知品类）」，否则"有什么优惠"也会被当成查库存，
        // 曾答成"暂时没有与「我平时都在这优惠」相关的在售图书"这种莫名其妙的话。
        return AVAILABILITY_PATTERN.matcher(question).find() || containsKnownCategory(question);
    }

    private boolean containsAny(String text, String[] words) {
        for (String word : words) {
            if (text.contains(word)) {
                return true;
            }
        }
        return false;
    }

    /** 问题里包含的最长书名（避免短书名误命中） */
    private BizBook longestTitleInQuestion(String question, List<BizBook> books) {
        String normalizedQuestion = normalizeQuestion(question);
        BizBook hit = null;
        int bestLength = 0;
        for (BizBook book : books) {
            String normalizedTitle = normalizeQuestion(book.getTitle());
            if (normalizedTitle.length() >= 2 && normalizedQuestion.contains(normalizedTitle)
                    && normalizedTitle.length() > bestLength) {
                hit = book;
                bestLength = normalizedTitle.length();
            }
        }
        return hit;
    }

    /** 剥掉疑问/客套/图书通用词，剩下的就是主题词（"你们店里卖恐龙书吗" → "恐龙"） */
    private String extractTopic(String question) {
        String topic = normalizeQuestion(question);
        for (String stop : TOPIC_STOP_WORDS) {
            topic = topic.replace(stop, "");
        }
        return topic.trim();
    }

    /** 按真实库存列书单，全程不经模型，保证不会出现不存在的书名 */
    private String buildStockListAnswer(String topic, List<BizBook> books) {
        books.sort((a, b) -> Integer.compare(
                b.getStock() == null ? 0 : b.getStock(),
                a.getStock() == null ? 0 : a.getStock()));
        int total = books.size();
        int limit = Math.min(5, total);
        // 结果被 LIMIT 截断时不能声称精确总数，显示为 50+
        String totalText = total >= stockSearchLimit ? stockSearchLimit + "+" : String.valueOf(total);
        StringBuilder sb = new StringBuilder();
        if (StringUtils.hasText(topic)) {
            sb.append("与「").append(topic).append("」相关的在售图书共 ").append(totalText).append(" 本：\n");
        } else {
            sb.append("当前在售图书共 ").append(totalText).append(" 本，例如：\n");
        }
        for (int i = 0; i < limit; i++) {
            BizBook book = books.get(i);
            sb.append(i + 1).append(". 《").append(book.getTitle()).append("》 ")
                    .append(plainMoney(book.getPrice())).append(" 元，库存 ")
                    .append(book.getStock() == null ? 0 : book.getStock()).append(" 件");
            if (StringUtils.hasText(book.getCategory())) {
                sb.append("（").append(book.getCategory()).append("）");
            }
            sb.append("\n");
        }
        if (total > limit) {
            sb.append("……等共 ").append(totalText).append(" 本，可在图书列表查看全部。");
        }
        return sb.toString().trim();
    }

    /** 书名匹配：归一化后相等或互相包含（容忍书名号、标点、副标题差异） */
    private boolean titleMatches(String title, String queryTitle) {
        if (!StringUtils.hasText(title) || !StringUtils.hasText(queryTitle)) {
            return false;
        }
        String a = normalizeQuestion(title);
        String b = normalizeQuestion(queryTitle);
        return a.equals(b) || a.contains(b) || b.contains(a);
    }

    /** 按真实库存/价格/上下架状态组织答复，全程不经过模型 */
    private String describeStock(BizBook book) {
        String title = book.getTitle();
        int stock = book.getStock() == null ? 0 : book.getStock();
        String price = plainMoney(book.getPrice());
        String category = StringUtils.hasText(book.getCategory()) ? "，分类：" + book.getCategory() : "";
        if (!"1".equals(book.getStatus())) {
            return "《" + title + "》目前是下架状态，暂时无法购买" + category + "。";
        }
        if (stock <= 0) {
            return "《" + title + "》暂时缺货（售价 " + price + " 元）" + category + "，可以关注补货。";
        }
        return "有的，《" + title + "》售价 " + price + " 元，当前库存 " + stock + " 件" + category
                + "，可在图书列表直接下单。";
    }

    /**
     * 图书推荐：结构化检索 biz_book 的真实数据后组织语言。
     * 为什么不用语义召回：知识库是 FAQ 条目（如"宝玉在地窖发现古籍"），会被当成图书推荐出去；
     * 且模型在没有真实书单时会自行编造书名与价格。这里把候选集限死在库存内，
     * 并在答案返回后再做一次书名/价格校验，越界则回退为确定性书单。
     */
    private String recommendBooks(Long userId, String question) {
        BigDecimal budget = extractBudget(question);
        List<BizBook> candidates = bizBookMapper.selectRecommendCandidates(budget, 30);
        if (CollectionUtils.isEmpty(candidates)) {
            String limitText = budget == null ? "" : "（预算 " + plainMoney(budget) + " 元以内）";
            return "当前没有符合条件的在售图书" + limitText + "，可以调整预算或换个分类看看。";
        }
        List<BizBook> ranked = rankByRelevance(question, candidates);
        List<BizBook> top = ranked.subList(0, Math.min(5, ranked.size()));

        StringBuilder bookList = new StringBuilder();
        for (BizBook b : top) {
            bookList.append("- ").append(b.getTitle())
                    .append(" | ").append(StringUtils.hasText(b.getCategory()) ? b.getCategory() : "未分类")
                    .append(" | ").append(plainMoney(b.getPrice())).append("元")
                    .append(" | 库存").append(b.getStock() == null ? 0 : b.getStock())
                    .append("\n");
        }
        Map<String, Object> params = Maps.newHashMap();
        params.put("bookList", bookList.toString().trim());
        params.put("question", question);
        String userContext = memoryService.buildUserContext(userId, question);
        params.put("userProfile", StringUtils.hasText(userContext) ? userContext : "无（新用户或暂无记忆）");
        if (StringUtils.hasText(userContext)) {
            log.info("注入用户画像/记忆：" + userContext.replace("\n", " "));
        }
        log.info("图书推荐候选：" + top.size() + " 本，预算=" + (budget == null ? "不限" : plainMoney(budget)));

        String answer = null;
        try {
            answer = chatClient.prompt()
                    .user(u -> u.text(RECOMMEND_PROMPT_TEMPLATE).params(params))
                    .call()
                    .content();
        } catch (Exception e) {
            log.info("推荐生成失败，回退为确定性书单：" + e.getMessage());
        }
        if (!isAnswerGroundedInBooks(answer, top, budget)) {
            log.info("推荐答案未通过真实性校验，回退为确定性书单：answer=" + answer);
            return buildDeterministicRecommendation(top, budget);
        }
        return answer;
    }

    /** 从提问里抽预算：优先「预算 120」，其次「120 元/块」，取最小值 */
    private BigDecimal extractBudget(String question) {
        BigDecimal byKeyword = null;
        Matcher m = Pattern.compile("预算[^0-9]{0,6}([0-9]+(?:\\.[0-9]+)?)").matcher(question);
        if (m.find()) {
            byKeyword = new BigDecimal(m.group(1));
        }
        BigDecimal minMoney = null;
        Matcher m2 = PRICE_PATTERN.matcher(question);
        while (m2.find()) {
            BigDecimal v = new BigDecimal(m2.group(1));
            if (minMoney == null || v.compareTo(minMoney) < 0) {
                minMoney = v;
            }
        }
        if (byKeyword != null) {
            return byKeyword;
        }
        return minMoney;
    }

    private String plainMoney(BigDecimal price) {
        return price == null ? "未知" : price.stripTrailingZeros().toPlainString();
    }

    /** 按「与问题的二元字重合度 + 库存」排序，让"恐龙/科幻"这类主题词能提到前面 */
    private List<BizBook> rankByRelevance(String question, List<BizBook> books) {
        Set<String> qGrams = bigrams(normalizeQuestion(question));
        List<BizBook> copy = new ArrayList<>(books);
        copy.sort((a, b) -> {
            int diff = relevanceScore(qGrams, b) - relevanceScore(qGrams, a);
            if (diff != 0) {
                return diff;
            }
            int stockA = a.getStock() == null ? 0 : a.getStock();
            int stockB = b.getStock() == null ? 0 : b.getStock();
            return stockB - stockA;
        });
        return copy;
    }

    private int relevanceScore(Set<String> qGrams, BizBook book) {
        StringBuilder sb = new StringBuilder();
        if (book.getTitle() != null) {
            sb.append(book.getTitle());
        }
        if (book.getCategory() != null) {
            sb.append(book.getCategory());
        }
        if (book.getDescription() != null) {
            sb.append(book.getDescription());
        }
        String nb = normalizeQuestion(sb.toString());
        if (nb.isEmpty()) {
            return 0;
        }
        int score = 0;
        for (String g : qGrams) {
            if (nb.contains(g)) {
                score++;
            }
        }
        return score;
    }

    private Set<String> bigrams(String s) {
        Set<String> set = new LinkedHashSet<>();
        if (!StringUtils.hasText(s)) {
            return set;
        }
        if (s.length() < 2) {
            set.add(s);
            return set;
        }
        for (int i = 0; i + 2 <= s.length(); i++) {
            set.add(s.substring(i, i + 2));
        }
        return set;
    }

    /** 答案真实性校验：书名必须在候选清单内，价格必须是清单价格或用户预算 */
    private boolean isAnswerGroundedInBooks(String answer, List<BizBook> books, BigDecimal budget) {
        if (!StringUtils.hasText(answer)) {
            return false;
        }
        Set<String> allowedTitles = new LinkedHashSet<>();
        Set<String> allowedPrices = new LinkedHashSet<>();
        for (BizBook b : books) {
            if (StringUtils.hasText(b.getTitle())) {
                allowedTitles.add(b.getTitle().trim());
            }
            if (b.getPrice() != null) {
                allowedPrices.add(plainMoney(b.getPrice()));
            }
        }
        String budgetText = budget == null ? null : plainMoney(budget);

        int titleCount = 0;
        Matcher tm = TITLE_PATTERN.matcher(answer);
        while (tm.find()) {
            titleCount++;
            String title = tm.group(1).trim();
            boolean matched = false;
            for (String allowed : allowedTitles) {
                if (allowed.equals(title) || allowed.contains(title) || title.contains(allowed)) {
                    matched = true;
                    break;
                }
            }
            if (!matched) {
                return false;
            }
        }
        if (titleCount == 0) {
            return false;
        }
        Matcher pm = PRICE_PATTERN.matcher(answer);
        while (pm.find()) {
            String price = plainMoney(new BigDecimal(pm.group(1)));
            if (allowedPrices.contains(price) || price.equals(budgetText)) {
                continue;
            }
            return false;
        }
        return true;
    }

    /** 兜底：完全按库存数据拼答案，不经过模型，保证不出现清单外的书名与价格 */
    private String buildDeterministicRecommendation(List<BizBook> books, BigDecimal budget) {
        StringBuilder sb = new StringBuilder();
        sb.append("根据当前在售库存，为您筛选到 ").append(books.size()).append(" 本");
        if (budget != null) {
            sb.append("（预算 ").append(plainMoney(budget)).append(" 元以内）");
        }
        sb.append("：\n");
        int i = 1;
        for (BizBook b : books) {
            sb.append(i++).append(". 《").append(b.getTitle()).append("》 ")
                    .append(plainMoney(b.getPrice())).append(" 元，库存 ")
                    .append(b.getStock() == null ? 0 : b.getStock()).append(" 件");
            if (StringUtils.hasText(b.getCategory())) {
                sb.append("，分类：").append(b.getCategory());
            }
            if (StringUtils.hasText(b.getDescription())) {
                sb.append("。").append(b.getDescription());
            }
            sb.append("\n");
        }
        return sb.toString().trim();
    }

    /** 是否推荐类问题：意图命中，或包含推荐特征词（防止 ai_intent 漏配导致失效） */
    private boolean isRecommendQuestion(String question, String intent) {
        if (RECOMMEND_INTENT.equals(intent)) {
            return true;
        }
        if (containsAny(question, RECOMMEND_HINTS)) {
            return true;
        }
        // 用户常用"表达偏好 + 预算"的方式求推荐（"我平时只看科幻小说，预算两百"），
        // 这类问法不含"推荐/书单"，早期会掉进普通 LLM 路径并编造书名售价。
        // 判定要求"偏好词 + 书类词/已知品类"同时出现，避免"我平时都在你们这买书"被误判。
        if (!containsAny(question, TASTE_HINTS)) {
            return false;
        }
        return containsAny(question, BOOK_WORDS) || containsKnownCategory(question);
    }

    /**
     * 问题里是否出现了图书分类（科幻/计算机/文学…）。
     * 让"我喜欢看科幻""有科幻的吗"这类不提"书"字的问法也能被识别。
     * 分类变动很低频，缓存 5 分钟，避免每句提问都查库。
     */
    private boolean containsKnownCategory(String question) {
        if (!StringUtils.hasText(question)) {
            return false;
        }
        for (String category : getCategories()) {
            if (category.length() >= 2 && question.contains(category)) {
                return true;
            }
        }
        return false;
    }

    private List<String> getCategories() {
        long now = System.currentTimeMillis();
        if (categoryCache.isEmpty() || now - categoryCacheAt > CATEGORY_CACHE_MILLIS) {
            categoryCache = bizBookMapper.selectBookCategories();
            categoryCacheAt = now;
        }
        return categoryCache;
    }

    /**
     * 判断书名号里的内容是不是"章节/篇目"而非书名。
     * 章节名通常很短（2~4 字）且常与"第X章/节/篇/卷"或"起航/归来/觉醒"这类叙事词相关。
     * 简单启发式：长度 < 2 或命中"章节卷"字样，或纯短叙事词，即视为章节。
     */
    private boolean isChapterLike(String title) {
        if (!StringUtils.hasText(title)) {
            return true;
        }
        if (title.length() < 2) {
            return true;
        }
        if (title.contains("章") || title.contains("节") || title.contains("篇")
                || title.contains("卷") || title.contains("序")) {
            return true;
        }
        return false;
    }

    /**
     * 兜底：大模型答案里出现库里不存在的《书名》时，说明模型在编书。
     * 直接改走结构化推荐（只列真实在售图书），并把编造内容记进日志便于复盘。
     * 若答案本身是"没有该书"的否认话术，则放行——那是诚实的回答。
     */
    private String guardHallucinatedTitles(Long userId, String question, String answer) {
        if (!StringUtils.hasText(answer) || isFallbackAnswer(answer)) {
            return answer;
        }
        // 明显是否认/说明类回答（"没有了""暂无该书"），不当作编造
        if (answer.contains("没有") || answer.contains("暂无") || answer.contains("无法")) {
            return answer;
        }
        // 只在"求购/推荐"语境下做书名校验：
        // 书籍内容问答会引用《星海纪事》这类上传的正文书名（不在 biz_book 商品表里），
        // 那是合法的，不该被当成"编造书名"误杀。
        if (!isRecommendQuestion(question, null) && !containsAny(question, STOCK_HINTS)) {
            return answer;
        }
        Matcher titleMatcher = TITLE_PATTERN.matcher(answer);
        List<String> mentioned = new ArrayList<>();
        while (titleMatcher.find()) {
            mentioned.add(titleMatcher.group(1).trim());
        }
        if (mentioned.isEmpty()) {
            return answer;
        }
        // 去掉"章节/篇目"等语境词：模型回答书籍内容时常写"第一章「起航」"，
        // 若把「起航」当书名校验，库里没有《起航》就会误杀正确答案。
        List<String> realCandidates = new ArrayList<>();
        for (String title : mentioned) {
            if (isChapterLike(title)) {
                continue;
            }
            realCandidates.add(title);
        }
        if (realCandidates.isEmpty()) {
            return answer;
        }
        List<String> existingTitles = bizBookMapper.selectBookTitles();
        List<String> invented = new ArrayList<>();
        for (String title : realCandidates) {
            boolean exists = false;
            for (String real : existingTitles) {
                if (titleMatches(real, title)) {
                    exists = true;
                    break;
                }
            }
            if (!exists) {
                invented.add(title);
            }
        }
        if (invented.isEmpty()) {
            return answer;
        }
        log.info("拦截疑似编造的书名：" + invented + "，问题=" + question);
        // 只有"确实在求推荐"的问题才改走书单；否则（如问优惠/活动）塞一份书单反而更答非所问
        if (!isRecommendQuestion(question, null)) {
            return "非常抱歉，您的问题暂时无法解答，请联系人工客服。";
        }
        String structured = recommendBooks(userId, question);
        log.info("已改为结构化推荐回复：" + structured.replace("\n", " "));
        return structured;
    }


    /** 轻量分段耗时埋点，便于确认优化到底省在哪一步 */
    private void logCost(String stage, long start) {
        log.info("[耗时] " + stage + ": " + (System.currentTimeMillis() - start) + " ms");
    }

    /**
     * 初始化知识库向量（系统启动时调用，将知识库内容写入向量库）
     */
    @Override
    public void initKnowledgeVector() {
        log.info("开始初始化知识库向量...");
        try {
            // 确保向量索引存在：不存在才建；存在则保留（绝不 DROPINDEX）。
            // 原因：RedisVectorConfig 用动态的 initializeSchema(!indexExists)，若启动时索引已存在，
            // 该字段会被设为 false；此时若先 FT.DROPINDEX 删掉索引，afterPropertiesSet 便不会再 FT.CREATE，
            // 索引将永远无法重建，导致全部走知识库的问答抛 "No such index aa_rag_index"。
            // 因此这里改为：索引不存在才建，且【绝不删除索引】，仅清理旧文档 hash 实现全量重建。
            boolean exists = checkIndexExists(redisTemplate, "aa_rag_index");
            if (!exists) {
                if (vectorStore instanceof InitializingBean) {
                    ((InitializingBean) vectorStore).afterPropertiesSet();
                }
            }
            // 全量重建语义：仅清理旧文档 hash（不删索引），避免脏数据堆积
            Set<String> oldDocKeys = redisTemplate.keys("aa_rag_prefix*");
            if (oldDocKeys != null && !oldDocKeys.isEmpty()) {
                // 保留书籍正文向量（key 形如 aa_rag_prefixbook-1-1），只清理知识库文档，
                // 否则每次重建知识库都会把上传的书籍内容一起删掉。
                oldDocKeys.removeIf(key -> key.startsWith("aa_rag_prefixbook-"));
                if (!oldDocKeys.isEmpty()) {
                    redisTemplate.delete(oldDocKeys);
                }
            }
            // 查询所有有效知识库
//            LambdaQueryWrapper<AIKnowledge> queryWrapper = new LambdaQueryWrapper<AIKnowledge>()
//                    .eq(AIKnowledge::getIsDeleted, 0);
//            List<AIKnowledge> knowledgeList = knowledgeMapper.selectList(queryWrapper);
            AiKnowledge aiKnowledge = new AiKnowledge();
            List<AiKnowledge> knowledgeList = knowledgeMapper.selectPageByCategory(aiKnowledge);

            if (CollectionUtils.isEmpty(knowledgeList)) {
                log.info("无有效知识库数据，向量初始化跳过");
                return;
            }

            // 转换为Document并写入向量库
            List<Document> documents = knowledgeList.stream().map(knowledge -> {
                Map<String, Object> metadata = Maps.newHashMap();
                // Redis 索引把 $.knowledgeId 定义为 TAG 字段，值必须是字符串。
                // 直接放 Long 会让 RediSearch 整条文档索引失败（FT.INFO 中
                // hash_indexing_failures 累加、num_docs 为 0），导致 similaritySearch 永远返回空。
                metadata.put("knowledgeId", String.valueOf(knowledge.getId()));
                metadata.put("category", knowledge.getCategory());
                metadata.put("question", knowledge.getQuestion());
                metadata.put("answer", knowledge.getAnswer());
                return new Document(knowledge.getQuestion() + " " + knowledge.getAnswer(), metadata);
            }).collect(Collectors.toList());

            vectorStore.add(documents);
            log.info("知识库向量初始化完成，共写入"+documents.size()+"条数据" );
        } catch (Exception e) {
            log.info("知识库向量初始化失败："+ e);
            throw new RuntimeException("知识库向量初始化失败", e);
        }
    }

    /**
     * 意图识别（基于关键词匹配+模糊查询）
     * @param question 用户提问
     * @return 识别的意图名称
     */
    /**
     * 从提问中提取订单号并查询真实订单状态。
     * 没有订单号或查不到时返回 null，由调用方继续走知识库问答流程。
     */
    private String queryOrderStatus(String question)
    {

        if (!StringUtils.hasText(question))
        {
            return null;
        }
        Matcher matcher = ORDER_NO_PATTERN.matcher(question);
        while (matcher.find())
        {
            String orderNo = matcher.group();
            BizOrder order = bizOrderMapper.selectBizOrderByOrderNo(orderNo);
            if (order == null)
            {
                continue;
            }
            String createTime = order.getCreateTime() == null
                    ? "—"
                    : new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(order.getCreateTime());
            return String.format(
                    "订单 %s 当前状态：%s。%n图书：%s，数量：%s，金额：%s 元；收货人：%s；下单时间：%s。",
                    order.getOrderNo(),
                    orderStatusText(order.getStatus()),
                    StringUtils.isEmpty(order.getBookTitle()) ? "—" : order.getBookTitle(),
                    order.getQuantity() == null ? "—" : order.getQuantity(),
                    order.getAmount() == null ? "—" : order.getAmount(),
                    StringUtils.isEmpty(order.getReceiver()) ? "—" : order.getReceiver(),
                    createTime);
        }
        return null;
    }

    /** 订单状态字典，与 biz_order.status 保持一致 */
    private String orderStatusText(String status)
    {
        if (status == null)
        {
            return "未知状态";
        }
        switch (status)
        {
            case "0": return "待付款";
            case "1": return "待发货";
            case "2": return "已发货";
            case "3": return "已完成";
            case "4": return "已退款";
            default:  return "未知状态(" + status + ")";
        }
    }

    /** 判断回答是否属于兜底/否定话术（为空或命中否定词都算没答上来） */
    private boolean isFallbackAnswer(String answer) {
        if (!StringUtils.hasText(answer)) {
            return true;
        }
        for (String marker : FALLBACK_MARKERS) {
            if (answer.contains(marker)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 把检索到的书籍片段格式化成 Prompt 可读的【书籍原文片段】段落，
     * 带上书名与章节，方便大模型引用来源、也便于用户核对。
     */
    private String formatBookChunks(List<Document> chunks) {
        StringBuilder sb = new StringBuilder("【书籍原文片段】\n");
        int index = 1;
        for (Document doc : chunks) {
            Map<String, Object> meta = doc.getMetadata();
            Object titleObj = meta.get("bookTitle");
            Object chapterObj = meta.get("chapter");
            String chapter = chapterObj == null ? null : String.valueOf(chapterObj);
            // metadata 的 chapter 可能没被检索回填，退化为取正文首行（长度合理时）
            if (!StringUtils.hasText(chapter)) {
                String text = doc.getText();
                int nl = text == null ? -1 : text.indexOf('\n');
                if (nl > 0 && nl <= 40) {
                    chapter = text.substring(0, nl).trim();
                }
            }
            sb.append("--- 片段").append(index++).append("：《")
                    .append(titleObj == null ? "未知图书" : titleObj).append("》");
            if (StringUtils.hasText(chapter)) {
                sb.append("（").append(chapter).append("）");
            }
            sb.append(" ---\n").append(doc.getText()).append("\n");
        }
        return sb.toString();
    }

    /**
     * 意图识别：一次性取出全部意图，在内存中用「用户问题是否包含意图关键词」做反向匹配。
     *
     * 原实现按空格/标点切分问句，再把每个 token 交给 selectByKeyword 反查数据库；
     * 而 SQL 是 keywords LIKE '%token%'（数据库字段包含用户词），方向反了：
     * 中文整句没有分隔符，会被当成一个长 token，短关键词字段永远不可能包含它，
     * 导致几乎所有完整问句都返回「未知意图」。
     *
     * 这里改为反向包含 question.contains(keyword)，并按命中词长度加权，
     * 长词比短词更能代表用户意图；同时把 N 次 DB 查询降为 1 次。
     */
    private String recognizeIntent(String question) {
        if (!StringUtils.hasText(question)) {
            return "未知意图";
        }
        List<AiIntent> allIntents = intentMapper.selectAllIntents();
        if (CollectionUtils.isEmpty(allIntents)) {
            return "未知意图";
        }

        Map<String, Integer> intentScoreMap = Maps.newHashMap();
        for (AiIntent intent : allIntents) {
            String intentName = intent.getIntentName();
            String keywords = intent.getKeywords();
            if (!StringUtils.hasText(intentName) || !StringUtils.hasText(keywords)) {
                continue;
            }
            for (String kw : keywords.split("[,，]")) {
                String word = kw.trim();
                // 单字关键词（如「书」「改」）容易误命中，直接跳过
                if (word.length() < 2 || !question.contains(word)) {
                    continue;
                }
                // 按命中词长度加权，上限 6，避免超长关键词过度放大
                intentScoreMap.merge(intentName, Math.min(word.length(), 6), Integer::sum);
            }
        }

        if (intentScoreMap.isEmpty()) {
            return "未知意图";
        }
        return intentScoreMap.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("未知意图");
    }

    /**
     * 编程式事务：保存对话记录+更新知识库命中次数
     */
    private void saveChatRecordAndUpdateKnowledge(Long userId, String question, String answer, List<Long> knowledgeIds) {
        // 开启事务
        DefaultTransactionDefinition transactionDefinition = new DefaultTransactionDefinition();
        TransactionStatus transactionStatus = transactionManager.getTransaction(transactionDefinition);

        try {
            // 1. 保存对话记录
            AiChatRecord chatRecord = new AiChatRecord();
            chatRecord.setUserId(userId);
            chatRecord.setUserQuestion(question);
            chatRecord.setAiAnswer(answer);
            chatRecord.setKnowledgeIds(CollectionUtils.isEmpty(knowledgeIds)
                    ? null
                    : knowledgeIds.stream().map(String::valueOf).collect(Collectors.joining(",")));
            chatRecord.setChatTime(new Date());
            chatRecordMapper.insertAiChatRecord(chatRecord);
            log.info("保存对话记录成功：recordId="+chatRecord.getId() );

            // 2. 批量更新知识库命中次数
            if (!CollectionUtils.isEmpty(knowledgeIds)) {
                int updateCount = knowledgeMapper.batchUpdateHitCount(knowledgeIds);
                log.info("更新知识库命中次数：knowledgeIds="+knowledgeIds+", 更新行数="+updateCount);
            }

            // 提交事务
            transactionManager.commit(transactionStatus);
        } catch (Exception e) {
            // 回滚事务
            transactionManager.rollback(transactionStatus);
            log.info("保存对话记录或更新知识库命中次数失败："+ e);
            throw new RuntimeException("事务执行失败", e);
        }
    }
    private boolean checkIndexExists(StringRedisTemplate redisTemplate, String indexName) {
        return Boolean.TRUE.equals(
                redisTemplate.execute((RedisCallback<Boolean>) connection -> {
                    try {
                        connection.execute("FT.INFO",
                                indexName.getBytes(StandardCharsets.UTF_8));
                        return true;   // 命令成功 = 索引存在
                    } catch (Exception e) {
                        return false;  // 报错 = 索引不存在
                    }
                })
        );
    }
}
