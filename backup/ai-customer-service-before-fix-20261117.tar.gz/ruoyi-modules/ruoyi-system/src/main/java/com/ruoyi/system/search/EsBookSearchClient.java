package com.ruoyi.system.search;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ruoyi.common.core.utils.StringUtils;
import com.ruoyi.system.domain.BizBook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * 图书 ES 检索客户端（直连 HTTP，不引入 ES Java 客户端）。
 *
 * 为什么不用官方客户端：
 *   1. Spring Boot 4.0.6 管理的是 elasticsearch-client 9.2.8，与服务端版本强耦合，
 *      换 ES 版本就要跟着换客户端，本地/生产容易踩版本矩阵；
 *   2. 本功能只需要 index / bulk / delete / search 四个 HTTP 接口，
 *      走 JDK HttpClient 零依赖、零版本问题，排障时 curl 能复现同一请求。
 *
 * 中文分词：使用 ES 内置 ngram tokenizer（min_gram=2,max_gram=2），
 * 等价于 MySQL 的 ngram，且**不需要安装 IK 插件**；bigram 也让英文单词
 * （Java → ja/av/va）能被命中——这正好绕开了 MySQL ngram 漏检英文词的问题。
 *
 * @author ruoyi
 */
@Component
public class EsBookSearchClient
{
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(2))
            .build();

    @Value("${ai.book.search.es-uri:http://127.0.0.1:9220}")
    private String esUri;

    @Value("${ai.book.search.index-name:biz_book_search}")
    private String indexName;

    @Value("${ai.book.search.es-enabled:true}")
    private boolean enabled;

    /** 索引定义：bigram 分词 + 只保留检索需要的字段 */
    private static final String INDEX_BODY = """
            {
              "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 0,
                "analysis": {
                  "tokenizer": {
                    "cjk_bigram": {
                      "type": "ngram",
                      "min_gram": 2,
                      "max_gram": 2,
                      "token_chars": ["letter", "digit"]
                    }
                  },
                  "analyzer": {
                    "cjk": {
                      "type": "custom",
                      "tokenizer": "cjk_bigram",
                      "filter": ["lowercase"]
                    }
                  }
                }
              },
              "mappings": {
                "properties": {
                  "bookId":         { "type": "long" },
                  "title":          { "type": "text", "analyzer": "cjk", "search_analyzer": "cjk" },
                  "titleKeyword":   { "type": "keyword" },
                  "author":         { "type": "text", "analyzer": "cjk" },
                  "category":       { "type": "text", "analyzer": "cjk" },
                  "description":    { "type": "text", "analyzer": "cjk" },
                  "status":         { "type": "keyword" },
                  "price":          { "type": "scaled_float", "scaling_factor": 100 },
                  "stock":          { "type": "integer" }
                }
              }
            }
            """;

    public boolean isEnabled()
    {
        return enabled;
    }

    public String getIndexName()
    {
        return indexName;
    }

    /** ES 是否可达 */
    public boolean ping()
    {
        try
        {
            return send("GET", "/", null).statusCode() == 200;
        }
        catch (Exception e)
        {
            return false;
        }
    }

    /** 索引不存在则创建（幂等） */
    public void ensureIndex() throws Exception
    {
        HttpResponse<String> head = send("HEAD", "/" + indexName, null);
        if (head.statusCode() == 200)
        {
            return;
        }
        HttpResponse<String> created = send("PUT", "/" + indexName, INDEX_BODY);
        if (created.statusCode() >= 300)
        {
            throw new IllegalStateException("创建索引失败：" + created.statusCode() + " " + created.body());
        }
    }

    /**
     * 删除并重建索引：全量重建时必须先删，
     * 否则已从 MySQL 删除的图书会留在索引里，检索出“幽灵数据”。
     */
    public void recreateIndex() throws Exception
    {
        HttpResponse<String> deleted = send("DELETE", "/" + indexName, null);
        if (deleted.statusCode() >= 300 && deleted.statusCode() != 404)
        {
            throw new IllegalStateException("删除索引失败：" + deleted.statusCode() + " " + deleted.body());
        }
        ensureIndex();
    }

    /** 单条写入（bookId 作为文档 id，天然幂等） */
    public void indexBook(BizBook book) throws Exception
    {
        String body = objectMapper.writeValueAsString(toDoc(book));
        // refresh=true：图书增删改后立刻可检索，避免"改完还要等 1 秒才生效"
        HttpResponse<String> resp = send("PUT", "/" + indexName + "/_doc/" + book.getBookId() + "?refresh=true", body);
        if (resp.statusCode() >= 300)
        {
            throw new IllegalStateException("写入图书索引失败：" + resp.statusCode() + " " + resp.body());
        }
    }

    public void deleteBook(Long bookId) throws Exception
    {
        HttpResponse<String> resp = send("DELETE", "/" + indexName + "/_doc/" + bookId, null);
        // 404 表示本来就没索引到，忽略
        if (resp.statusCode() >= 300 && resp.statusCode() != 404)
        {
            throw new IllegalStateException("删除图书索引失败：" + resp.statusCode() + " " + resp.body());
        }
    }

    /** 批量重建（每批 500 条） */
    public int bulkIndex(List<BizBook> books) throws Exception
    {
        if (books == null || books.isEmpty())
        {
            return 0;
        }
        int done = 0;
        for (int i = 0; i < books.size(); i += 500)
        {
            List<BizBook> batch = books.subList(i, Math.min(i + 500, books.size()));
            StringBuilder ndjson = new StringBuilder();
            for (BizBook book : batch)
            {
                ObjectNode meta = objectMapper.createObjectNode();
                meta.putObject("index")
                        .put("_index", indexName)
                        .put("_id", String.valueOf(book.getBookId()));
                ndjson.append(objectMapper.writeValueAsString(meta)).append('\n');
                ndjson.append(objectMapper.writeValueAsString(toDoc(book))).append('\n');
            }
            // refresh=true：让写入立即可见。ES 默认 1s 才刷新，
            // 重建后马上去 _count/_search 会看到 0 条，误以为索引没写进去。
            HttpResponse<String> resp = send("POST", "/_bulk?refresh=true", ndjson.toString());
            if (resp.statusCode() >= 300)
            {
                throw new IllegalStateException("批量索引失败：" + resp.statusCode() + " " + resp.body());
            }
            done += batch.size();
        }
        return done;
    }

    /** 索引中的文档数（索引不存在返回 -1） */
    public long count() throws Exception
    {
        HttpResponse<String> resp = send("GET", "/" + indexName + "/_count", null);
        if (resp.statusCode() != 200)
        {
            return -1;
        }
        return objectMapper.readTree(resp.body()).path("count").asLong(0);
    }

    /**
     * 按关键词检索图书 ID。
     *
     * 打分优先级：书名完全相等(20) > 书名短语命中(8) > 书名分词命中(5)
     *            > 分类命中(2) > 简介命中(1)
     *
     * @param keyword    关键词
     * @param onSaleOnly true 只返回上架图书
     * @param limit      最大条数
     * @return bookId 列表；ES 不可用时抛异常由上层降级
     */
    public List<Long> searchIds(String keyword, boolean onSaleOnly, int limit) throws Exception
    {
        ObjectNode root = objectMapper.createObjectNode();
        root.put("size", limit);
        root.putArray("_source").add("bookId");

        ObjectNode bool = root.putObject("query").putObject("bool");
        ArrayNode should = bool.putArray("should");
        should.add(termQuery("titleKeyword", keyword, 20));
        should.add(matchPhrase("title", keyword, 8));
        should.add(matchQuery("title", keyword, 5));
        should.add(matchQuery("category", keyword, 2));
        should.add(matchQuery("description", keyword, 1));
        bool.put("minimum_should_match", 1);
        if (onSaleOnly)
        {
            bool.putArray("filter").add(termQuery("status", "1", null));
        }

        HttpResponse<String> resp = send("POST", "/" + indexName + "/_search",
                objectMapper.writeValueAsString(root));
        if (resp.statusCode() >= 300)
        {
            throw new IllegalStateException("ES 检索失败：" + resp.statusCode() + " " + resp.body());
        }
        JsonNode hits = objectMapper.readTree(resp.body()).path("hits").path("hits");
        List<Long> ids = new ArrayList<>(hits.size());
        for (JsonNode hit : hits)
        {
            long id = hit.path("_source").path("bookId").asLong(0);
            if (id > 0)
            {
                ids.add(id);
            }
        }
        return ids;
    }

    private ObjectNode termQuery(String field, String value, Integer boost)
    {
        ObjectNode node = objectMapper.createObjectNode();
        ObjectNode term = node.putObject("term").putObject(field);
        term.put("value", value);
        if (boost != null)
        {
            term.put("boost", boost);
        }
        return node;
    }

    private ObjectNode matchQuery(String field, String value, int boost)
    {
        ObjectNode node = objectMapper.createObjectNode();
        node.putObject("match").putObject(field).put("query", value).put("boost", boost);
        return node;
    }

    private ObjectNode matchPhrase(String field, String value, int boost)
    {
        ObjectNode node = objectMapper.createObjectNode();
        node.putObject("match_phrase").putObject(field).put("query", value).put("boost", boost);
        return node;
    }

    /** 只索引检索需要的字段；价格/库存仍以 MySQL 为准，ES 里仅作参考 */
    private ObjectNode toDoc(BizBook book)
    {
        ObjectNode doc = objectMapper.createObjectNode();
        doc.put("bookId", book.getBookId());
        doc.put("title", nullSafe(book.getTitle()));
        doc.put("titleKeyword", nullSafe(book.getTitle()));
        doc.put("author", nullSafe(book.getAuthor()));
        doc.put("category", nullSafe(book.getCategory()));
        doc.put("description", nullSafe(book.getDescription()));
        doc.put("status", nullSafe(book.getStatus()));
        if (book.getPrice() != null)
        {
            doc.put("price", book.getPrice().doubleValue());
        }
        doc.put("stock", book.getStock() == null ? 0 : book.getStock());
        return doc;
    }

    private String nullSafe(String value)
    {
        return StringUtils.hasText(value) ? value : "";
    }

    private HttpResponse<String> send(String method, String path, String body) throws Exception
    {
        HttpRequest.Builder builder = HttpRequest.newBuilder(URI.create(esUri + path))
                .timeout(Duration.ofSeconds(5));
        if (body == null)
        {
            builder.method(method, HttpRequest.BodyPublishers.noBody());
        }
        else
        {
            builder.header("Content-Type", "application/json; charset=UTF-8");
            builder.method(method, HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8));
        }
        return httpClient.send(builder.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
    }
}
