-- ============================================================
-- 补充「图书管理」意图
-- 背景：ai_intent 初始只有 修改密码 / 查询发货 / 申请退款 / 质量问题 四条，
--       图书上下架、库存、状态类问法全部识别为「未知意图」。
-- 幂等：intent_name 上有唯一索引 uk_intent_name，重复执行不会产生重复行。
-- 执行库：ry-cloud
-- ============================================================

INSERT INTO `ai_intent` (`intent_name`, `intent_desc`, `keywords`)
SELECT '图书管理',
       '图书上下架、库存、状态相关',
       '上架,下架,上架下架,图书上下架,图书状态,库存,图书管理,图书上架,图书下架'
WHERE NOT EXISTS (
    SELECT 1 FROM `ai_intent` WHERE `intent_name` = '图书管理'
);

-- 校验
SELECT `id`, `intent_name`, `keywords` FROM `ai_intent` ORDER BY `id`;
